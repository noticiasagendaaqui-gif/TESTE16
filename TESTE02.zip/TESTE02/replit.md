# Overview

This is a comprehensive business directory and transportation Progressive Web App (PWA) for the São José da Lapa region and north metro area of Belo Horizonte, Brazil. The application provides offline-capable business listings, bus schedule information, tourist attractions, and mapping functionality for the region's cities. It serves as a complete commercial guide with both static content deployment options and full-stack functionality.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with **React 18** using **Vite** as the build tool for fast development and optimized production builds. The application follows a component-based architecture with modular, reusable components.

**UI Framework**: Uses **shadcn/ui** component library built on top of **Radix UI** primitives, providing accessible and customizable components. The design system is implemented with **Tailwind CSS** with custom CSS variables for consistent theming.

**State Management**: Utilizes **TanStack Query (React Query)** for server state management, caching, and synchronization. Local state is managed through React hooks and context providers for authentication and location services.

**Routing**: Implements client-side routing with **Wouter**, a lightweight alternative to React Router, supporting main navigation (Home, Lines, Cities, Map, Settings, Admin).

**PWA Implementation**: Full Progressive Web App capabilities including:
- Service worker for offline functionality and multi-layer caching strategy
- Web app manifest for installability on mobile devices
- Responsive design optimized for mobile-first experience
- Touch-friendly interactions with Material Design principles

## Backend Architecture
The backend follows a **REST API** architecture built with **Express.js** and **TypeScript**. The server provides JSON endpoints for business listings, bus schedules, city information, and administrative functions.

**API Structure**: RESTful endpoints including:
- `/api/cities` - City information and business listings
- `/api/businesses` - Business directory with categories and search
- `/api/categories` - Business category management
- `/api/lines` - Bus line management and schedules
- `/api/auth` - Authentication and session management
- `/api/favorites` - User favorite management

**Data Storage**: Uses an in-memory storage implementation (`MemStorage`) that simulates database operations. The system includes Drizzle ORM configuration for PostgreSQL when a database is available, allowing seamless migration from in-memory to persistent storage.

**Session Management**: Express sessions with configurable security settings for authentication and user management.

**Development Setup**: Vite middleware integration allows for hot module replacement during development, with production builds serving static assets through Express.

## Static Deployment Option
The application includes a complete static deployment solution in the `public-static/` directory for hosting on cPanel or similar shared hosting environments. This includes:
- Standalone HTML/CSS/JS files with embedded data
- Service worker for offline functionality
- Web app manifest for PWA capabilities
- No server dependencies required

## Data Management
**Schema Definition**: Shared TypeScript schemas using **Drizzle ORM** and **Zod** for validation, ensuring type safety across the entire application stack.

**Caching Strategy**: Multi-layered caching approach:
- Service worker caches static assets and API responses
- React Query handles client-side data caching with automatic invalidation
- localStorage fallback for critical data when offline

**Location Services**: Geolocation integration with fallback options for detecting user's nearest city and providing location-aware business recommendations.

# External Dependencies

**Database**: Optional PostgreSQL database using Drizzle ORM. Supports external providers like Supabase, Neon, Railway, and Render. Falls back to in-memory storage when DATABASE_URL is not configured.

**Maps and Location**: Integration with OpenStreetMap through Nominatim API for geocoding and tourist attraction searches. Geolocation API for user positioning.

**Real-time Transit**: Framework for integrating with external bus tracking APIs, with fallback to static schedule data.

**Authentication**: BCrypt for password hashing and Express sessions for user management.

**External Services**: Support for integrating third-party business data sources and transit APIs.

**Hosting Flexibility**: Designed to work with both dynamic hosting (Node.js servers) and static hosting environments (cPanel, GitHub Pages) through dual deployment strategies.

# Recent Changes (September 2025)

## External Business API Integration System
Implemented comprehensive system for importing business data from multiple external APIs:

**External Business Service**: Created `external-business-service.ts` with integrations for:
- **OpenStreetMap/Nominatim**: Free geocoding and business location searches
- **BrasilAPI**: CNPJ lookup and company validation for Brazilian businesses
- **ViaCEP**: Address lookup and postal code validation
- **Google Maps API**: Enhanced location services (optional, requires API key)
- **Foursquare Places**: Business discovery and details (optional, requires API key)

**Administrative Interface**: Enhanced admin panel with new "Empresas" tab providing:
- City-based business search functionality
- CNPJ lookup for specific companies
- Bulk auto-population of businesses by city
- Manual import selection with duplicate detection
- Real-time search results with business validation

**API Endpoints**: Added administrative endpoints in `auth-routes.ts`:
- `/api/auth/external/search-businesses` - Search businesses by city name
- `/api/auth/external/search-cnpj` - Lookup company by CNPJ
- `/api/auth/external/geocode` - Geocode addresses to coordinates
- `/api/auth/external/search-nearby` - Find businesses near coordinates
- `/api/auth/external/import-businesses` - Import selected businesses to database
- `/api/auth/external/auto-populate` - Automatically populate city with businesses
- `/api/auth/external/search-cep` - Address lookup by postal code

**Data Validation**: Comprehensive validation and duplicate detection system:
- Business data validation before import
- Duplicate checking by name and address
- Automatic category assignment based on business type
- Coordinate validation and geocoding fallbacks
- Rate limiting for external API calls

**Fallback Strategy**: Multi-tier approach ensuring reliability:
- Primary: OpenStreetMap (free, no API key required)
- Secondary: BrasilAPI for Brazilian business data
- Optional: Google Maps and Foursquare for enhanced data (requires API keys)
- Graceful degradation when external services are unavailable