// Dados locais para funcionar sem servidor Node.js
const appData = {
  categories: [
    { id: '1', name: 'Transporte', icon: 'fas fa-bus', color: 'blue', count: 25 },
    { id: '2', name: 'Restaurantes', icon: 'fas fa-utensils', color: 'red', count: 42 },
    { id: '3', name: 'Hotéis', icon: 'fas fa-bed', color: 'purple', count: 18 },
    { id: '4', name: 'Saúde', icon: 'fas fa-hospital', color: 'green', count: 31 },
    { id: '5', name: 'Serviços', icon: 'fas fa-wrench', color: 'orange', count: 56 },
    { id: '6', name: 'Varejo', icon: 'fas fa-shopping-cart', color: 'pink', count: 38 },
    { id: '7', name: 'Educação', icon: 'fas fa-graduation-cap', color: 'indigo', count: 22 },
    { id: '8', name: 'Lazer', icon: 'fas fa-gamepad', color: 'yellow', count: 15 }
  ],

  cities: [
    { 
      id: '1', 
      name: 'São José da Lapa', 
      businessCount: 89,
      description: 'Industrial, Centro, Eldorado',
      image: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400&h=250&fit=crop'
    },
    { 
      id: '2', 
      name: 'Vespasiano', 
      businessCount: 112,
      description: 'Centro, Morro Alto, Residencial',
      image: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400&h=250&fit=crop'
    },
    { 
      id: '3', 
      name: 'Pedro Leopoldo', 
      businessCount: 76,
      description: 'Centro, Nova Prata, Fidalgo',
      image: 'https://images.unsplash.com/photo-1486299267070-83823f5448dd?w=400&h=250&fit=crop'
    },
    { 
      id: '4', 
      name: 'Lagoa Santa', 
      businessCount: 95,
      description: 'Centro, Aeroporto, Palmital',
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=250&fit=crop'
    },
    { 
      id: '5', 
      name: 'Ribeirão das Neves', 
      businessCount: 134,
      description: 'Centro, Veneza, Justinópolis',
      image: 'https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?w=400&h=250&fit=crop'
    },
    { 
      id: '6', 
      name: 'Santa Luzia', 
      businessCount: 108,
      description: 'Centro, Duquesa, São Benedito',
      image: 'https://images.unsplash.com/photo-1515378791036-0648a814a05f?w=400&h=250&fit=crop'
    }
  ],

  businesses: [
    {
      id: '1',
      name: 'Restaurante Sabor Mineiro',
      category: 'Restaurantes',
      city: 'São José da Lapa',
      address: 'Rua Principal, 123 - Centro',
      phone: '(31) 3328-1234',
      rating: 4.5,
      reviews: 89,
      priceRange: '$$',
      hours: 'Seg-Dom: 11h-22h',
      description: 'Comida mineira tradicional com ambiente familiar'
    },
    {
      id: '2',
      name: 'Auto Center Lapa',
      category: 'Serviços',
      city: 'São José da Lapa',
      address: 'Av. Industrial, 456',
      phone: '(31) 3328-5678',
      rating: 4.2,
      reviews: 56,
      priceRange: '$',
      hours: 'Seg-Sex: 8h-18h, Sáb: 8h-12h',
      description: 'Mecânica especializada em veículos nacionais e importados'
    },
    {
      id: '3',
      name: 'Farmácia Central',
      category: 'Saúde',
      city: 'Vespasiano',
      address: 'Rua do Comércio, 789',
      phone: '(31) 3621-9999',
      rating: 4.7,
      reviews: 124,
      priceRange: '$$',
      hours: 'Seg-Dom: 7h-22h',
      description: 'Farmácia 24h com delivery, medicamentos e perfumaria'
    },
    {
      id: '4',
      name: 'Hotel Pousada do Norte',
      category: 'Hotéis',
      city: 'Pedro Leopoldo',
      address: 'Av. Principal, 321',
      phone: '(31) 3662-4444',
      rating: 4.3,
      reviews: 78,
      priceRange: '$$$',
      hours: '24 horas',
      description: 'Hospedagem confortável com café da manhã incluído'
    },
    {
      id: '5',
      name: 'Supermercado Família',
      category: 'Varejo',
      city: 'Lagoa Santa',
      address: 'Rua das Compras, 159',
      phone: '(31) 3681-7777',
      rating: 4.1,
      reviews: 203,
      priceRange: '$$',
      hours: 'Seg-Dom: 7h-22h',
      description: 'Supermercado completo com açougue, padaria e hortifrúti'
    },
    {
      id: '6',
      name: 'Escola Futuro Brilhante',
      category: 'Educação',
      city: 'Ribeirão das Neves',
      address: 'Rua da Educação, 753',
      phone: '(31) 3627-3333',
      rating: 4.6,
      reviews: 95,
      priceRange: '$$$',
      hours: 'Seg-Sex: 7h-17h',
      description: 'Ensino fundamental e médio com método inovador'
    }
  ],

  busLines: [
    {
      id: '1',
      number: '201',
      name: 'Terminal BH Norte - São José da Lapa',
      route: 'Via Centro, Eldorado',
      frequency: '15-20 min',
      city: 'São José da Lapa'
    },
    {
      id: '2',
      number: '301',
      name: 'Vespasiano Centro - Terminal BH Norte',
      route: 'Via Morro Alto',
      frequency: '15-20 min',
      city: 'Vespasiano'
    },
    {
      id: '3',
      number: '401',
      name: 'Pedro Leopoldo - BH Centro',
      route: 'Via Vespasiano, Lagoa Santa',
      frequency: '30-35 min',
      city: 'Pedro Leopoldo'
    },
    {
      id: '4',
      number: '501',
      name: 'Lagoa Santa - Aeroporto Confins',
      route: 'Via Centro, Palmital',
      frequency: '20-25 min',
      city: 'Lagoa Santa'
    },
    {
      id: '5',
      number: '601',
      name: 'Ribeirão das Neves - Terminal BH Norte',
      route: 'Via Vespasiano',
      frequency: '15-20 min',
      city: 'Ribeirão das Neves'
    },
    {
      id: '6',
      number: '701',
      name: 'Santa Luzia - BH Centro',
      route: 'Via Av. Cristiano Machado',
      frequency: '20-25 min',
      city: 'Santa Luzia'
    }
  ]
};

// Estado da aplicação
let currentSection = 'home';
let filteredData = null;

// PWA Install
let deferredPrompt;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
  loadCategories();
  loadCities();
  loadBusinesses();
  loadBusLines();
  setupPWA();
});

// Carregar categorias
function loadCategories() {
  const grid = document.getElementById('categoriesGrid');
  grid.innerHTML = appData.categories.map(category => `
    <div class="card category-card p-4 text-center cursor-pointer" onclick="filterByCategory('${category.name}')">
      <i class="${category.icon} text-2xl mb-2"></i>
      <h3 class="font-semibold text-sm">${category.name}</h3>
      <p class="text-xs opacity-80">${category.count} empresas</p>
    </div>
  `).join('');
}

// Carregar cidades
function loadCities() {
  const grid = document.getElementById('citiesGrid');
  grid.innerHTML = appData.cities.map(city => `
    <div class="card overflow-hidden cursor-pointer" onclick="filterByCity('${city.name}')">
      <img src="${city.image}" alt="${city.name}" class="w-full h-32 object-cover">
      <div class="p-4">
        <h3 class="font-semibold mb-1">${city.name}</h3>
        <p class="text-sm text-gray-600 mb-2">${city.description}</p>
        <div class="flex items-center justify-between">
          <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${city.businessCount} empresas</span>
          <i class="fas fa-arrow-right text-blue-500"></i>
        </div>
      </div>
    </div>
  `).join('');
}

// Carregar empresas
function loadBusinesses() {
  const container = document.getElementById('businessesList');
  const businesses = filteredData || appData.businesses;
  
  container.innerHTML = businesses.map(business => `
    <div class="card business-card p-4">
      <div class="flex justify-between items-start mb-2">
        <h3 class="font-semibold text-lg">${business.name}</h3>
        <span class="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">${business.category}</span>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
        <div>
          <p class="text-sm text-gray-600 mb-1">
            <i class="fas fa-map-marker-alt text-blue-500 mr-2"></i>
            ${business.address}
          </p>
          <p class="text-sm text-gray-600 mb-1">
            <i class="fas fa-phone text-green-500 mr-2"></i>
            ${business.phone}
          </p>
          <p class="text-sm text-gray-600">
            <i class="fas fa-clock text-orange-500 mr-2"></i>
            ${business.hours}
          </p>
        </div>
        <div>
          <div class="flex items-center mb-2">
            <div class="rating mr-2">
              ${'★'.repeat(Math.floor(business.rating))}${'☆'.repeat(5-Math.floor(business.rating))}
            </div>
            <span class="text-sm text-gray-600">${business.rating} (${business.reviews} avaliações)</span>
          </div>
          <span class="text-sm font-semibold text-green-600">${business.priceRange}</span>
        </div>
      </div>
      
      <p class="text-sm text-gray-700 mb-3">${business.description}</p>
      
      <div class="flex space-x-2">
        <a href="tel:${business.phone}" class="btn text-sm flex-1 text-center">
          <i class="fas fa-phone mr-1"></i> Ligar
        </a>
        <a href="https://maps.google.com/?q=${encodeURIComponent(business.address)}" target="_blank" class="btn text-sm flex-1 text-center bg-green-500">
          <i class="fas fa-map-marker-alt mr-1"></i> Ver no Mapa
        </a>
      </div>
    </div>
  `).join('');
}

// Carregar linhas de ônibus
function loadBusLines() {
  const container = document.getElementById('busList');
  const lines = filteredData || appData.busLines;
  
  container.innerHTML = lines.map(line => `
    <div class="card p-4">
      <div class="flex items-center justify-between mb-2">
        <div class="flex items-center">
          <div class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-bold mr-3">
            ${line.number}
          </div>
          <h3 class="font-semibold">${line.name}</h3>
        </div>
        <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
          ${line.frequency}
        </span>
      </div>
      
      <p class="text-sm text-gray-600 mb-3">
        <i class="fas fa-route text-blue-500 mr-2"></i>
        ${line.route}
      </p>
      
      <div class="flex justify-between items-center">
        <span class="text-xs text-gray-500">${line.city}</span>
        <button class="btn text-xs" onclick="showSchedule('${line.number}')">
          <i class="fas fa-clock mr-1"></i> Ver Horários
        </button>
      </div>
    </div>
  `).join('');
}

// Navegação entre seções
function showSection(section) {
  // Reset filter when changing sections
  filteredData = null;
  
  // Hide all sections
  document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
  
  // Show selected section
  document.getElementById(section + 'Section').classList.remove('hidden');
  
  // Update navigation
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  event.target.closest('.nav-item').classList.add('active');
  
  currentSection = section;
  
  // Reload content for the section
  if (section === 'businesses') {
    loadBusinesses();
  } else if (section === 'bus') {
    loadBusLines();
  }
}

// Busca
function searchData() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  
  if (!query) {
    filteredData = null;
    if (currentSection === 'businesses') loadBusinesses();
    if (currentSection === 'bus') loadBusLines();
    return;
  }
  
  if (currentSection === 'home' || currentSection === 'businesses') {
    filteredData = appData.businesses.filter(business => 
      business.name.toLowerCase().includes(query) ||
      business.category.toLowerCase().includes(query) ||
      business.city.toLowerCase().includes(query) ||
      business.description.toLowerCase().includes(query)
    );
    if (currentSection === 'home') {
      showSection('businesses');
    } else {
      loadBusinesses();
    }
  } else if (currentSection === 'bus') {
    filteredData = appData.busLines.filter(line => 
      line.name.toLowerCase().includes(query) ||
      line.number.includes(query) ||
      line.city.toLowerCase().includes(query) ||
      line.route.toLowerCase().includes(query)
    );
    loadBusLines();
  }
}

// Filtros
function filterByCategory(category) {
  filteredData = appData.businesses.filter(business => business.category === category);
  showSection('businesses');
}

function filterByCity(city) {
  filteredData = appData.businesses.filter(business => business.city === city);
  showSection('businesses');
}

// Ver horários (simulação)
function showSchedule(lineNumber) {
  const schedules = [
    '05:30', '06:00', '06:30', '07:00', '07:30', '08:00', '08:30', '09:00',
    '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00',
    '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00',
    '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00'
  ];
  
  alert(`Horários da Linha ${lineNumber}:\n\n${schedules.join(' • ')}\n\n* Horários aproximados, sujeitos a alterações`);
}

// PWA Setup
function setupPWA() {
  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(registration => {
      console.log('SW registered:', registration);
    }).catch(error => {
      console.log('SW registration failed:', error);
    });
  }

  // Install prompt
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    setTimeout(() => {
      if (!localStorage.getItem('pwa-dismissed')) {
        document.getElementById('installPrompt').classList.remove('hidden');
      }
    }, 5000);
  });

  window.addEventListener('appinstalled', (evt) => {
    console.log('App installed');
    document.getElementById('installPrompt').classList.add('hidden');
  });
}

function installApp() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      console.log('User choice:', choiceResult.outcome);
      deferredPrompt = null;
    });
  }
  document.getElementById('installPrompt').classList.add('hidden');
}

function dismissInstall() {
  document.getElementById('installPrompt').classList.add('hidden');
  localStorage.setItem('pwa-dismissed', 'true');
}