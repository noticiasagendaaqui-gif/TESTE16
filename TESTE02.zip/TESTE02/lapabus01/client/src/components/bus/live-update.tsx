import { Card, CardContent } from "@/components/ui/card";
import type { LiveUpdate as LiveUpdateType } from "@shared/schema";
import { Info, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface LiveUpdateProps {
  update: LiveUpdateType;
}

export function LiveUpdate({ update }: LiveUpdateProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return CheckCircle;
      case "warning":
        return AlertTriangle;
      case "info":
      default:
        return Info;
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case "success":
        return "text-secondary";
      case "warning":
        return "text-accent";
      case "info":
      default:
        return "text-primary";
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case "success":
        return "bg-secondary/10";
      case "warning":
        return "bg-accent/10";
      case "info":
      default:
        return "bg-primary/10";
    }
  };

  const Icon = getIcon(update.type);
  
  const timeAgo = update.createdAt 
    ? Math.floor((Date.now() - new Date(update.createdAt).getTime()) / 60000)
    : 0;

  return (
    <Card className="material-elevation-1 animate-slide-up">
      <CardContent className="p-3">
        <div className="flex items-start space-x-3">
          <div className={cn(
            "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
            getBgColor(update.type)
          )}>
            <Icon className={cn("w-4 h-4", getIconColor(update.type))} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-foreground" data-testid={`update-message-${update.id}`}>
              {update.message}
            </p>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              {timeAgo < 1 ? "Agora mesmo" : `${timeAgo} min atrás`}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
