import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { realTimeService, type RealTimeBusPosition } from "@/services/realTimeService";
import { MapPin, RefreshCw, Wifi, WifiOff, Navigation } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface RealTimeStatusProps {
  lineNumber?: string;
  className?: string;
}

export function RealTimeStatus({ lineNumber, className }: RealTimeStatusProps) {
  const [positions, setPositions] = useState<RealTimeBusPosition[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkConnection();
    loadPositions();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadPositions, 30000);
    return () => clearInterval(interval);
  }, [lineNumber]);

  const checkConnection = async () => {
    const available = await realTimeService.isRealTimeAvailable();
    setIsConnected(available);
  };

  const loadPositions = async () => {
    setIsLoading(true);
    try {
      const allPositions = await realTimeService.getBusPositions();
      
      // Filter by line number if specified
      const filteredPositions = lineNumber 
        ? allPositions.filter(pos => pos.lineCode === lineNumber)
        : allPositions.slice(0, 10); // Show top 10 for general view
      
      setPositions(filteredPositions);
      setLastUpdate(new Date());
      setIsConnected(true);
      
      if (filteredPositions.length > 0) {
        toast({
          title: "📍 Posições Atualizadas",
          description: `${filteredPositions.length} ônibus em tempo real`,
        });
      }
    } catch (error) {
      console.error('Failed to load bus positions:', error);
      setIsConnected(false);
    } finally {
      setIsLoading(false);
    }
  };

  const getDistanceFromCenter = (lat: number, lon: number): string => {
    // Aproximate distance from BH center (-19.9167, -43.9345)
    const centerLat = -19.9167;
    const centerLon = -43.9345;
    
    const distance = Math.sqrt(
      Math.pow(lat - centerLat, 2) + Math.pow(lon - centerLon, 2)
    ) * 111; // Rough conversion to km
    
    return distance < 1 ? `${(distance * 1000).toFixed(0)}m` : `${distance.toFixed(1)}km`;
  };

  const formatTime = (timestamp: string): string => {
    try {
      return new Date(timestamp).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'N/A';
    }
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-primary" />
            <span>Posições em Tempo Real</span>
            {isConnected ? (
              <Badge variant="secondary" className="text-xs">
                <Wifi className="w-3 h-3 mr-1" />
                Online
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs">
                <WifiOff className="w-3 h-3 mr-1" />
                Offline
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={loadPositions}
            disabled={isLoading}
            className="w-8 h-8"
            data-testid="button-refresh-positions"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
        {lastUpdate && (
          <p className="text-xs text-muted-foreground">
            Última atualização: {lastUpdate.toLocaleTimeString('pt-BR')}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading && positions.length === 0 ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-16 rounded-lg" />
            ))}
          </div>
        ) : positions.length > 0 ? (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {positions.map((position, index) => (
              <div
                key={`${position.vehicleId}-${index}`}
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                data-testid={`bus-position-${position.vehicleId}`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Navigation className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm">
                      Linha {position.lineCode}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Veículo {position.vehicleId}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {getDistanceFromCenter(position.latitude, position.longitude)} do centro
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono text-muted-foreground">
                    {position.latitude.toFixed(4)}, {position.longitude.toFixed(4)}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatTime(position.timestamp)}
                  </div>
                  {position.speed && (
                    <div className="text-xs text-secondary">
                      {Math.round(position.speed)} km/h
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <MapPin className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">
              {isConnected 
                ? "Nenhum ônibus encontrado"
                : "Dados em tempo real indisponíveis"
              }
            </p>
            {lineNumber && (
              <p className="text-xs mt-1">
                Linha {lineNumber} não encontrada
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}