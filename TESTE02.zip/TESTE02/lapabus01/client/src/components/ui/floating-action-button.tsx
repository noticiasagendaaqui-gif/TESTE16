import { Button } from "./button";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface FloatingActionButtonProps {
  onClick?: () => void;
  className?: string;
  children?: React.ReactNode;
  "data-testid"?: string;
}

export function FloatingActionButton({ 
  onClick, 
  className, 
  children = <Plus className="w-6 h-6" />,
  "data-testid": testId
}: FloatingActionButtonProps) {
  return (
    <Button
      size="icon"
      className={cn(
        "fixed bottom-20 right-4 w-14 h-14 rounded-full material-elevation-2 touch-target ripple-effect animate-bounce-soft z-40",
        className
      )}
      onClick={onClick}
      data-testid={testId}
    >
      {children}
    </Button>
  );
}
