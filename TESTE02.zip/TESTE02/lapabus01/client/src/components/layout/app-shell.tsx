import { BottomNavigation } from "./bottom-navigation";
import { FloatingActionButton } from "../ui/floating-action-button";
import { useState } from "react";

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <div className="min-h-screen flex flex-col app-safe-area">
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto hide-scrollbar pull-to-refresh p-4">
        {children}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
      
      {/* Floating Action Button */}
      <FloatingActionButton 
        onClick={() => setShowSearch(!showSearch)}
        data-testid="fab-quick-search"
      />
    </div>
  );
}
