import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Navigation, X, AlertCircle, CheckCircle } from 'lucide-react';
import { useLocation } from '@/contexts/LocationContext';

export function LocationBanner() {
  const [dismissed, setDismissed] = useState(false);
  const {
    loading,
    error,
    permissionDenied,
    nearestCity,
    cityDistance,
    selectedCity,
    requestLocation,
    setSelectedCity,
  } = useLocation();

  // Se o usuário dispensou o banner, não mostrar
  if (dismissed) return null;

  // Se já temos uma cidade selecionada (manual ou automática), mostrar cidade atual
  if (selectedCity && !loading) {
    return (
      <Card className="mb-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-full">
                <MapPin className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-green-800">
                    {selectedCity.name}
                  </span>
                  {nearestCity && selectedCity.id === nearestCity.id && (
                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Detectado automaticamente
                    </Badge>
                  )}
                  {cityDistance && (
                    <Badge variant="outline" className="text-xs">
                      ~{Math.round(cityDistance)}km
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-green-600">
                  Mostrando conteúdo para sua região
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedCity(null)}
                className="text-green-700 hover:bg-green-100"
              >
                Alterar cidade
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setDismissed(true)}
                className="text-green-700 hover:bg-green-100"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Se houve erro de permissão, mostrar opção para tentar novamente
  if (permissionDenied) {
    return (
      <Alert className="mb-4 bg-orange-50 border-orange-200">
        <AlertCircle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="flex items-center justify-between">
          <div>
            <span className="text-orange-800">
              Permita o acesso à localização para ver conteúdo da sua região
            </span>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            <Button
              variant="outline"
              size="sm"
              onClick={requestLocation}
              className="border-orange-300 text-orange-700 hover:bg-orange-100"
            >
              <Navigation className="h-4 w-4 mr-1" />
              Permitir localização
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="text-orange-700 hover:bg-orange-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  // Se houver outro tipo de erro, mostrar erro
  if (error && !loading) {
    return (
      <Alert className="mb-4 bg-red-50 border-red-200">
        <AlertCircle className="h-4 w-4 text-red-600" />
        <AlertDescription className="flex items-center justify-between">
          <div>
            <span className="text-red-800">{error}</span>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            <Button
              variant="outline"
              size="sm"
              onClick={requestLocation}
              className="border-red-300 text-red-700 hover:bg-red-100"
            >
              Tentar novamente
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="text-red-700 hover:bg-red-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  // Se estiver carregando, mostrar loading
  if (loading) {
    return (
      <Card className="mb-4 bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-full">
              <Navigation className="h-4 w-4 text-blue-600 animate-pulse" />
            </div>
            <div>
              <span className="font-medium text-blue-800">
                Detectando sua localização...
              </span>
              <p className="text-sm text-blue-600">
                Aguarde enquanto identificamos sua região
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Caso padrão: solicitar permissão de localização
  return (
    <Card className="mb-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-full">
              <MapPin className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <span className="font-medium text-blue-800">
                Descubra o que há perto de você
              </span>
              <p className="text-sm text-blue-600">
                Permita acesso à localização para ver empresas e serviços da sua região
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              onClick={requestLocation}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Navigation className="h-4 w-4 mr-1" />
              Permitir localização
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="text-blue-700 hover:bg-blue-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}