import { useState, useEffect } from "react";
import { useToast } from "./use-toast";

const FAVORITES_KEY = "busapp_favorites";
const USER_ID = "anonymous"; // For future user system

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const stored = localStorage.getItem(FAVORITES_KEY);
    if (stored) {
      try {
        setFavorites(JSON.parse(stored));
      } catch (error) {
        console.error("Failed to parse favorites:", error);
      }
    }
  }, []);

  const saveFavorites = (newFavorites: string[]) => {
    setFavorites(newFavorites);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
  };

  const isFavorite = (lineId: string): boolean => {
    return favorites.includes(lineId);
  };

  const addToFavorites = async (lineId: string) => {
    if (isFavorite(lineId)) return;

    const newFavorites = [...favorites, lineId];
    saveFavorites(newFavorites);

    // Sync with server
    try {
      await fetch("/api/favorites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: USER_ID, lineId }),
      });
    } catch (error) {
      console.error("Failed to sync favorite to server:", error);
    }

    toast({
      title: "Adicionado aos favoritos",
      description: "Linha adicionada à sua lista de favoritos",
    });
  };

  const removeFromFavorites = async (lineId: string) => {
    if (!isFavorite(lineId)) return;

    const newFavorites = favorites.filter(id => id !== lineId);
    saveFavorites(newFavorites);

    // Sync with server
    try {
      await fetch("/api/favorites", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: USER_ID, lineId }),
      });
    } catch (error) {
      console.error("Failed to remove favorite from server:", error);
    }

    toast({
      title: "Removido dos favoritos",
      description: "Linha removida da sua lista de favoritos",
    });
  };

  const toggleFavorite = (lineId: string) => {
    if (isFavorite(lineId)) {
      removeFromFavorites(lineId);
    } else {
      addToFavorites(lineId);
    }
  };

  return {
    favorites,
    isFavorite,
    addToFavorites,
    removeFromFavorites,
    toggleFavorite,
  };
}
