import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, Clock, Building2 } from "lucide-react";

interface City {
  id: string;
  name: string;
  slug: string;
  state: string;
  population: number | null;
  distanceFromBH: number | null;
  description: string | null;
  banner: string | null;
  coordinates: string | null;
  isActive: boolean;
  createdAt: Date;
}

export default function CitiesPage() {
  const { data: cities = [], isLoading } = useQuery({
    queryKey: ["/api/cities"],
    queryFn: async () => {
      const response = await fetch("/api/cities");
      const result = await response.json();
      return result.data as City[];
    },
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Cidades da Região
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Carregando cidades da região metropolitana...
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const formatPopulation = (population: number | null) => {
    if (!population) return "N/A";
    return new Intl.NumberFormat("pt-BR").format(population);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Cidades da Região
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Explore as cidades da região metropolitana de Belo Horizonte e suas empresas de transporte
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cities.map((city) => (
          <Link key={city.id} href={`/cities/${city.slug}`}>
            <Card 
              className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02] bg-gradient-to-br from-white to-blue-50 dark:from-gray-800 dark:to-gray-900 border border-blue-100 dark:border-blue-800"
              data-testid={`card-city-${city.slug}`}
            >
              {city.banner && (
                <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-lg relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/20"></div>
                  <div className="absolute bottom-2 left-4 text-white">
                    <Building2 className="h-6 w-6" />
                  </div>
                </div>
              )}
              
              <CardHeader className="pb-3">
                <CardTitle className="text-xl text-gray-900 dark:text-white flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  {city.name}
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {city.state}
                  </Badge>
                </CardTitle>
                
                <CardDescription className="text-gray-600 dark:text-gray-300">
                  {city.description || "Cidade da região metropolitana"}
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                      <Users className="h-4 w-4" />
                      <span>População</span>
                    </div>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {formatPopulation(city.population)}
                    </span>
                  </div>

                  {city.distanceFromBH && (
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                        <Clock className="h-4 w-4" />
                        <span>Distância de BH</span>
                      </div>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {city.distanceFromBH} km
                      </span>
                    </div>
                  )}

                  <div className="pt-2 border-t border-gray-100 dark:border-gray-700">
                    <div className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                      Ver empresas de transporte →
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {cities.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Nenhuma cidade encontrada
          </h3>
          <p className="text-gray-600 dark:text-gray-300">
            Não há cidades cadastradas no momento.
          </p>
        </div>
      )}
    </div>
  );
}