import { useQuery } from "@tanstack/react-query";
import { SearchBar } from "@/components/bus/search-bar";
import { LineCard } from "@/components/bus/line-card";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { BusLine, CityRegion } from "@shared/schema";
import { useState } from "react";
import { Filter, X } from "lucide-react";

export default function Lines() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  const { data: busLines, isLoading } = useQuery<{ success: boolean; data: BusLine[] }>({
    queryKey: ["/api/lines"],
  });

  const { data: regions } = useQuery<{ success: boolean; data: CityRegion[] }>({
    queryKey: ["/api/regions"],
  });

  const { data: searchResults } = useQuery<{ success: boolean; data: BusLine[] }>({
    queryKey: ["/api/lines/search"],
    queryFn: async () => {
      const response = await fetch(`/api/lines/search?q=${encodeURIComponent(searchQuery)}`);
      return response.json();
    },
    enabled: searchQuery.length > 0,
  });

  const handleRegionFilter = (regionSlug: string) => {
    setSelectedRegions(prev => 
      prev.includes(regionSlug) 
        ? prev.filter(r => r !== regionSlug)
        : [...prev, regionSlug]
    );
  };

  const clearFilters = () => {
    setSelectedRegions([]);
    setSearchQuery("");
  };

  // Filter lines by search and regions
  let displayLines = searchQuery.length > 0 
    ? searchResults?.data || [] 
    : busLines?.data || [];

  // Apply region filter
  if (selectedRegions.length > 0) {
    displayLines = displayLines.filter(line => selectedRegions.includes(line.region));
  }

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Todas as Linhas</h1>
            <p className="text-muted-foreground text-sm">
              {displayLines.length} linha{displayLines.length !== 1 ? 's' : ''} disponíve{displayLines.length !== 1 ? 'is' : 'l'}
            </p>
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center space-x-2"
            data-testid="button-toggle-filters"
          >
            <Filter className="w-4 h-4" />
            <span>Filtros</span>
            {selectedRegions.length > 0 && (
              <Badge variant="secondary" className="ml-1">
                {selectedRegions.length}
              </Badge>
            )}
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Input
            type="text"
            placeholder="Buscar linha ou destino..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10"
            data-testid="input-search-lines"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          {(searchQuery || selectedRegions.length > 0) && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute inset-y-0 right-0 w-10 h-full"
              onClick={clearFilters}
              data-testid="button-clear-filters"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Filters */}
        {showFilters && (
          <Card className="animate-slide-up">
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-3">Filtrar por Região</h3>
              <div className="flex flex-wrap gap-2">
                {regions?.data?.map((region) => (
                  <Button
                    key={region.id}
                    variant={selectedRegions.includes(region.slug) ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleRegionFilter(region.slug)}
                    className="text-xs"
                    data-testid={`filter-region-${region.slug}`}
                  >
                    {region.name}
                    {selectedRegions.includes(region.slug) && <X className="w-3 h-3 ml-1" />}
                  </Button>
                ))}
              </div>
              {selectedRegions.length > 0 && (
                <div className="mt-3 pt-3 border-t">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearFilters}
                    className="text-xs text-muted-foreground"
                    data-testid="button-clear-all-filters"
                  >
                    Limpar todos os filtros
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Results */}
      <section className="space-y-4">
        {searchQuery && (
          <div className="text-sm text-muted-foreground">
            {displayLines.length} resultado{displayLines.length !== 1 ? 's' : ''} para "{searchQuery}"
          </div>
        )}
        
        <div className="space-y-3">
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-16 bg-muted rounded-lg" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : displayLines.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="text-muted-foreground">
                  {searchQuery 
                    ? `Nenhuma linha encontrada para "${searchQuery}"`
                    : "Nenhuma linha disponível"
                  }
                </div>
              </CardContent>
            </Card>
          ) : (
            displayLines.map((line) => (
              <LineCard key={line.id} line={line} />
            ))
          )}
        </div>
      </section>

      {/* Bottom padding for navigation */}
      <div className="h-20" />
    </div>
  );
}
