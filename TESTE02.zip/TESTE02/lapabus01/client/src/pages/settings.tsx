import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  Bell, 
  Download, 
  Smartphone, 
  Info, 
  MessageCircle, 
  Star,
  MapPin,
  Clock,
  Shield
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Link } from "wouter";

export default function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [locationAccess, setLocationAccess] = useState(false);
  const [offlineMode, setOfflineMode] = useState(true);
  const { toast } = useToast();

  const handleInstallApp = () => {
    toast({
      title: "Instalar App",
      description: "Use o menu do seu navegador para adicionar à tela inicial",
    });
  };

  const handleFeedback = () => {
    toast({
      title: "Feedback",
      description: "Redirecionando para formulário de feedback...",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-foreground">Configurações</h1>
        <p className="text-sm text-muted-foreground">
          Personalize sua experiência no BH Norte
        </p>
      </div>

      {/* App Info */}
      <Card className="material-elevation-1">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 24 24">
                <path d="M4 16c0 .88.39 1.67 1 2.22V20a2 2 0 002 2h1a2 2 0 002-2v-1.78c.61-.55 1-1.34 1-2.22V8a4 4 0 00-8 0v8zM14 16c0 .88.39 1.67 1 2.22V20a2 2 0 002 2h1a2 2 0 002-2v-1.78c.61-.55 1-1.34 1-2.22V8a4 4 0 00-8 0v8z"/>
              </svg>
            </div>
            <span>Guia Horários BH Norte</span>
            <Badge variant="secondary">v1.0.0</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Portal completo de horários de ônibus para a região metropolitana de BH Norte
          </p>
          
          <Button 
            onClick={handleInstallApp}
            className="w-full material-elevation-1 touch-target"
            data-testid="button-install-app"
          >
            <Download className="w-4 h-4 mr-2" />
            Instalar como App
          </Button>
        </CardContent>
      </Card>

      {/* Preferences */}
      <Card className="material-elevation-1">
        <CardHeader>
          <CardTitle>Preferências</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="flex items-center space-x-2 text-base">
                <Bell className="w-4 h-4" />
                <span>Notificações</span>
              </Label>
              <p className="text-sm text-muted-foreground">
                Receba alertas sobre atrasos e mudanças
              </p>
            </div>
            <Switch
              checked={notifications}
              onCheckedChange={setNotifications}
              data-testid="switch-notifications"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="flex items-center space-x-2 text-base">
                <MapPin className="w-4 h-4" />
                <span>Localização</span>
              </Label>
              <p className="text-sm text-muted-foreground">
                Permitir acesso para encontrar paradas próximas
              </p>
            </div>
            <Switch
              checked={locationAccess}
              onCheckedChange={setLocationAccess}
              data-testid="switch-location"
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="flex items-center space-x-2 text-base">
                <Smartphone className="w-4 h-4" />
                <span>Modo Offline</span>
              </Label>
              <p className="text-sm text-muted-foreground">
                Sincronizar dados para uso sem internet
              </p>
            </div>
            <Switch
              checked={offlineMode}
              onCheckedChange={setOfflineMode}
              data-testid="switch-offline"
            />
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card className="material-elevation-1">
        <CardHeader>
          <CardTitle>Estatísticas de Uso</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center space-y-2 p-3 bg-primary/10 rounded-xl">
              <div className="text-3xl font-bold text-primary">65</div>
              <div className="text-xs text-muted-foreground font-medium">Linhas Ativas</div>
            </div>
            <div className="text-center space-y-2 p-3 bg-secondary/10 rounded-xl">
              <div className="text-3xl font-bold text-secondary">6</div>
              <div className="text-xs text-muted-foreground font-medium">Regiões Atendidas</div>
            </div>
            <div className="text-center space-y-2 p-3 bg-accent/10 rounded-xl">
              <div className="text-3xl font-bold text-accent">2000+</div>
              <div className="text-xs text-muted-foreground font-medium">Horários/Dia</div>
            </div>
            <div className="text-center space-y-2 p-3 bg-muted rounded-xl">
              <div className="text-3xl font-bold text-foreground">24h</div>
              <div className="text-xs text-muted-foreground font-medium">Disponibilidade</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="space-y-3">
        <Link href="/login">
          <Button 
            variant="default" 
            className="w-full justify-start material-elevation-1 touch-target"
            data-testid="button-admin"
          >
            <Shield className="w-4 h-4 mr-2" />
            Acesso Administrativo
          </Button>
        </Link>

        <Button 
          variant="outline" 
          className="w-full justify-start material-elevation-1 touch-target"
          onClick={handleFeedback}
          data-testid="button-feedback"
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Enviar Feedback
        </Button>

        <Button 
          variant="outline" 
          className="w-full justify-start material-elevation-1 touch-target"
          data-testid="button-rate"
        >
          <Star className="w-4 h-4 mr-2" />
          Avaliar App
        </Button>

        <Button 
          variant="outline" 
          className="w-full justify-start material-elevation-1 touch-target"
          data-testid="button-about"
        >
          <Info className="w-4 h-4 mr-2" />
          Sobre o App
        </Button>
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-muted-foreground pb-4">
        <p>© 2025 Guia Horários BH Norte</p>
        <p className="mt-1">Desenvolvido para a comunidade da região metropolitana</p>
      </div>

      {/* Bottom padding for navigation */}
      <div className="h-20" />
    </div>
  );
}
