export const APP_CONFIG = {
  name: "Guia Horários BH Norte",
  shortName: "BH Norte",
  description: "Consulte horários de ônibus da região metropolitana de BH Norte",
  version: "1.0.0",
  themeColor: "#1976D2",
  backgroundColor: "#FAFAFA",
} as const;

export const API_ENDPOINTS = {
  lines: "/api/lines",
  schedules: (lineId: string) => `/api/lines/${lineId}/schedules`,
  search: "/api/lines/search",
  liveUpdates: "/api/live-updates",
  regions: "/api/regions",
  favorites: "/api/favorites",
  time: "/api/time",
} as const;

export const STORAGE_KEYS = {
  favorites: "busapp_favorites",
  settings: "busapp_settings",
  recentSearches: "busapp_recent_searches",
  installDismissed: "busapp_install_dismissed",
} as const;

export const BUS_LINE_COLORS = {
  primary: { bg: "bg-primary/10", text: "text-primary", color: "hsl(213, 76%, 45%)" },
  secondary: { bg: "bg-secondary/10", text: "text-secondary", color: "hsl(123, 43%, 35%)" },
  accent: { bg: "bg-accent/10", text: "text-accent", color: "hsl(36, 77%, 49%)" },
  muted: { bg: "bg-muted", text: "text-muted-foreground", color: "hsl(210, 40%, 96%)" },
} as const;

export const REGIONS = {
  "sao-jose-lapa": { name: "São José da Lapa", color: "primary" },
  "vespasiano": { name: "Vespasiano", color: "secondary" },
  "pedro-leopoldo": { name: "Pedro Leopoldo", color: "accent" },
  "lagoa-santa": { name: "Lagoa Santa", color: "muted" },
} as const;

export const NOTIFICATION_TYPES = {
  info: { icon: "Info", color: "text-primary", bg: "bg-primary/10" },
  warning: { icon: "AlertTriangle", color: "text-accent", bg: "bg-accent/10" },
  success: { icon: "CheckCircle", color: "text-secondary", bg: "bg-secondary/10" },
  error: { icon: "XCircle", color: "text-destructive", bg: "bg-destructive/10" },
} as const;
