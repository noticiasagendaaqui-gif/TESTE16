import React, { createContext, useContext, useEffect, useState } from 'react';
import { useGeolocation, findNearestCity } from '@/hooks/useGeolocation';
import { useQuery } from '@tanstack/react-query';

interface LocationContextType {
  // Dados de geolocalização
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null;
  error: string | null;
  loading: boolean;
  permissionDenied: boolean;
  
  // Cidade detectada
  nearestCity: any | null;
  cityDistance: number | null;
  
  // Ações
  requestLocation: () => void;
  setSelectedCity: (city: any) => void;
  selectedCity: any | null;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export function LocationProvider({ children }: { children: React.ReactNode }) {
  const geolocation = useGeolocation();
  const [selectedCity, setSelectedCity] = useState<any | null>(null);
  const [nearestCity, setNearestCity] = useState<any | null>(null);
  const [cityDistance, setCityDistance] = useState<number | null>(null);

  // Buscar lista de cidades
  const { data: cities = [] } = useQuery({
    queryKey: ["/api/cities"],
    queryFn: async () => {
      const response = await fetch("/api/cities");
      const result = await response.json();
      return result.data;
    },
  });

  // Encontrar cidade mais próxima quando a localização for obtida
  useEffect(() => {
    if (geolocation.latitude && geolocation.longitude && cities.length > 0) {
      const nearest = findNearestCity(
        geolocation.latitude,
        geolocation.longitude,
        cities
      );
      
      if (nearest) {
        setNearestCity(nearest);
        setCityDistance(nearest.distance);
        
        // Se não há cidade selecionada manualmente, usar a mais próxima
        if (!selectedCity) {
          setSelectedCity(nearest);
        }
      }
    }
  }, [geolocation.latitude, geolocation.longitude, cities, selectedCity]);

  // Carregar cidade salva no localStorage
  useEffect(() => {
    const savedCity = localStorage.getItem('selectedCity');
    if (savedCity) {
      try {
        const city = JSON.parse(savedCity);
        setSelectedCity(city);
      } catch (error) {
        console.error('Erro ao carregar cidade salva:', error);
      }
    }
  }, []);

  // Salvar cidade selecionada no localStorage
  const handleSetSelectedCity = (city: any) => {
    setSelectedCity(city);
    if (city) {
      localStorage.setItem('selectedCity', JSON.stringify(city));
    } else {
      localStorage.removeItem('selectedCity');
    }
  };

  const contextValue: LocationContextType = {
    // Dados de geolocalização
    latitude: geolocation.latitude,
    longitude: geolocation.longitude,
    accuracy: geolocation.accuracy,
    error: geolocation.error,
    loading: geolocation.loading,
    permissionDenied: geolocation.permissionDenied,
    
    // Cidade detectada
    nearestCity,
    cityDistance,
    
    // Ações
    requestLocation: geolocation.requestLocation,
    setSelectedCity: handleSetSelectedCity,
    selectedCity,
  };

  return (
    <LocationContext.Provider value={contextValue}>
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
}