import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const busLines = pgTable("bus_lines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  number: text("number").notNull().unique(),
  name: text("name").notNull(),
  route: text("route").notNull(),
  frequency: text("frequency").notNull(), // "15-20 min"
  region: text("region").notNull(),
  color: text("color").default("primary"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const busSchedules = pgTable("bus_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  lineId: varchar("line_id").references(() => busLines.id).notNull(),
  departureTime: text("departure_time").notNull(), // "14:35"
  direction: text("direction").notNull(), // "Terminal BH Norte -> São José da Lapa"
  weekdays: boolean("weekdays").default(true),
  weekends: boolean("weekends").default(true),
  isActive: boolean("is_active").default(true),
});

export const liveUpdates = pgTable("live_updates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // "info", "warning", "success"
  lineId: varchar("line_id").references(() => busLines.id),
  priority: integer("priority").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cityRegions = pgTable("city_regions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  lineCount: integer("line_count").default(0),
  color: text("color").default("primary"),
  isActive: boolean("is_active").default(true),
});

export const userFavorites = pgTable("user_favorites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(), // For future user system
  lineId: varchar("line_id").references(() => busLines.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cities nearby table
export const cities = pgTable("cities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  state: text("state").notNull().default("MG"),
  population: integer("population"),
  distanceFromBH: integer("distance_from_bh"), // in kilometers
  description: text("description"),
  banner: text("banner"), // banner image URL
  coordinates: text("coordinates"), // lat,lng format
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Business directory table (replaces transport companies)
export const businesses = pgTable("businesses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cityId: varchar("city_id").references(() => cities.id).notNull(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  category: text("category").notNull(), // "transport", "restaurant", "hotel", "services", etc.
  subcategory: text("subcategory"), // "bus", "taxi", "pizza", "hotel", "pharmacy", etc.
  phone: text("phone"),
  whatsapp: text("whatsapp"),
  email: text("email"),
  website: text("website"),
  address: text("address"),
  neighborhood: text("neighborhood"),
  postalCode: text("postal_code"),
  coordinates: text("coordinates"), // lat,lng format
  banner: text("banner"), // business banner/logo URL
  images: jsonb("images"), // JSON array of image URLs
  description: text("description"),
  services: jsonb("services"), // JSON array of services offered
  workingHours: jsonb("working_hours"), // JSON object with detailed hours
  priceRange: text("price_range"), // "$", "$$", "$$$", "$$$$"
  rating: integer("rating").default(0), // 1-5 stars
  reviewCount: integer("review_count").default(0),
  isVerified: boolean("is_verified").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business categories table
export const businessCategories = pgTable("business_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(), // Lucide icon name
  color: text("color").default("primary"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
});

// Business reviews table
export const businessReviews = pgTable("business_reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessId: varchar("business_id").references(() => businesses.id).notNull(),
  userName: text("user_name").notNull(),
  userEmail: text("user_email"),
  rating: integer("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertBusLineSchema = createInsertSchema(busLines).omit({
  id: true,
  createdAt: true,
});

export const insertBusScheduleSchema = createInsertSchema(busSchedules).omit({
  id: true,
});

export const insertLiveUpdateSchema = createInsertSchema(liveUpdates).omit({
  id: true,
  createdAt: true,
});

export const insertCityRegionSchema = createInsertSchema(cityRegions).omit({
  id: true,
});

export const insertUserFavoriteSchema = createInsertSchema(userFavorites).omit({
  id: true,
  createdAt: true,
});

export const insertCitySchema = createInsertSchema(cities).omit({
  id: true,
  createdAt: true,
});

export const insertBusinessSchema = createInsertSchema(businesses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBusinessCategorySchema = createInsertSchema(businessCategories).omit({
  id: true,
});

export const insertBusinessReviewSchema = createInsertSchema(businessReviews).omit({
  id: true,
  createdAt: true,
});

// Legacy schema for compatibility
export const insertTransportCompanySchema = insertBusinessSchema;

// Types
export type BusLine = typeof busLines.$inferSelect;
export type InsertBusLine = z.infer<typeof insertBusLineSchema>;

export type BusSchedule = typeof busSchedules.$inferSelect;
export type InsertBusSchedule = z.infer<typeof insertBusScheduleSchema>;

export type LiveUpdate = typeof liveUpdates.$inferSelect;
export type InsertLiveUpdate = z.infer<typeof insertLiveUpdateSchema>;

export type CityRegion = typeof cityRegions.$inferSelect;
export type InsertCityRegion = z.infer<typeof insertCityRegionSchema>;

export type UserFavorite = typeof userFavorites.$inferSelect;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;

// Extended types for API responses
export type BusLineWithSchedules = BusLine & {
  schedules: BusSchedule[];
  nextDeparture?: string;
};

export type CityRegionWithLines = CityRegion & {
  lines: BusLine[];
};

export type City = typeof cities.$inferSelect;
export type InsertCity = z.infer<typeof insertCitySchema>;

export type Business = typeof businesses.$inferSelect;
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;

export type BusinessCategory = typeof businessCategories.$inferSelect;
export type InsertBusinessCategory = z.infer<typeof insertBusinessCategorySchema>;

export type BusinessReview = typeof businessReviews.$inferSelect;
export type InsertBusinessReview = z.infer<typeof insertBusinessReviewSchema>;

export type CityWithBusinesses = City & {
  businesses: Business[];
  businessCount: number;
  topCategories: string[];
};

export type BusinessWithReviews = Business & {
  reviews: BusinessReview[];
  averageRating: number;
};

// Legacy types for compatibility
export type TransportCompany = Business;
export type InsertTransportCompany = InsertBusiness;
export type CityWithCompanies = CityWithBusinesses;
