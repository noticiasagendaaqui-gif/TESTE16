/**
 * Script para testar a conexão com o banco PostgreSQL externo
 * Execute: node server/test-db-connection.js
 */

import { Pool } from 'pg';

async function testDatabaseConnection() {
  console.log('🔍 Testando conexão com banco PostgreSQL externo...\n');

  if (!process.env.DATABASE_URL) {
    console.error('❌ ERROR: DATABASE_URL não configurada');
    console.log('Configure a variável DATABASE_URL com sua connection string PostgreSQL');
    console.log('Exemplo: postgresql://usuario:senha@host:porta/database');
    process.exit(1);
  }

  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    max: 1, // Só 1 conexão para teste
    connectionTimeoutMillis: 5000,
  });

  try {
    console.log('🔗 Conectando ao banco...');
    const client = await pool.connect();
    
    console.log('✅ Conexão estabelecida com sucesso!\n');

    // Teste básico
    const result = await client.query('SELECT NOW() as current_time, version()');
    console.log('📅 Hora do servidor:', result.rows[0].current_time);
    console.log('🗄️ Versão PostgreSQL:', result.rows[0].version);

    // Verificar se existem tabelas
    const tablesResult = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `);
    
    console.log('\n📋 Tabelas existentes:', tablesResult.rows.length);
    if (tablesResult.rows.length > 0) {
      tablesResult.rows.forEach(row => {
        console.log('  -', row.table_name);
      });
    } else {
      console.log('  (Nenhuma tabela encontrada - isso é normal para banco novo)');
    }

    client.release();
    await pool.end();

    console.log('\n✅ Teste de conexão concluído com sucesso!');
    console.log('\n📝 Próximos passos:');
    console.log('1. Execute: npm run db:push');
    console.log('2. Isso criará todas as tabelas necessárias');
    console.log('3. Seu app estará pronto para usar o banco externo!');

  } catch (error) {
    console.error('\n❌ Erro na conexão:', error.message);
    
    if (error.code === 'ENOTFOUND') {
      console.log('\n💡 Dicas:');
      console.log('- Verifique se o host está correto');
      console.log('- Confirme se tem acesso à internet');
    } else if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Dicas:');
      console.log('- Verifique se a porta está correta');
      console.log('- Confirme se o servidor PostgreSQL está rodando');
    } else if (error.message.includes('password')) {
      console.log('\n💡 Dicas:');
      console.log('- Verifique usuário e senha na DATABASE_URL');
      console.log('- Confirme as credenciais no painel do provedor');
    } else if (error.message.includes('ssl')) {
      console.log('\n💡 Dicas:');
      console.log('- Adicione ?sslmode=require na URL');
      console.log('- Ou configure SSL no provedor');
    }
    
    process.exit(1);
  }
}

testDatabaseConnection();