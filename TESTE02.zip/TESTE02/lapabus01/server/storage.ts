import {
  type BusLine,
  type InsertBusLine,
  type BusSchedule,
  type InsertBusSchedule,
  type LiveUpdate,
  type InsertLiveUpdate,
  type CityRegion,
  type InsertCityRegion,
  type UserFavorite,
  type InsertUserFavorite,
  type BusLineWithSchedules,
  type CityRegionWithLines,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Bus Lines
  getBusLines(): Promise<BusLine[]>;
  getBusLine(id: string): Promise<BusLine | undefined>;
  getBusLineWithSchedules(id: string): Promise<BusLineWithSchedules | undefined>;
  createBusLine(line: InsertBusLine): Promise<BusLine>;
  searchBusLines(query: string): Promise<BusLine[]>;

  // Bus Schedules
  getSchedulesForLine(lineId: string): Promise<BusSchedule[]>;
  createSchedule(schedule: InsertBusSchedule): Promise<BusSchedule>;

  // Live Updates
  getLiveUpdates(): Promise<LiveUpdate[]>;
  getActiveLiveUpdates(): Promise<LiveUpdate[]>;
  createLiveUpdate(update: InsertLiveUpdate): Promise<LiveUpdate>;

  // City Regions
  getCityRegions(): Promise<CityRegion[]>;
  getCityRegionWithLines(slug: string): Promise<CityRegionWithLines | undefined>;
  createCityRegion(region: InsertCityRegion): Promise<CityRegion>;

  // User Favorites
  getUserFavorites(userId: string): Promise<UserFavorite[]>;
  addToFavorites(favorite: InsertUserFavorite): Promise<UserFavorite>;
  removeFromFavorites(userId: string, lineId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private busLines: Map<string, BusLine> = new Map();
  private busSchedules: Map<string, BusSchedule> = new Map();
  private liveUpdates: Map<string, LiveUpdate> = new Map();
  private cityRegions: Map<string, CityRegion> = new Map();
  private userFavorites: Map<string, UserFavorite> = new Map();

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample data for São José da Lapa region
    const regions: InsertCityRegion[] = [
      {
        name: "São José da Lapa",
        slug: "sao-jose-lapa",
        description: "Centro, Industrial, Eldorado",
        lineCount: 8,
        color: "primary",
        isActive: true,
      },
      {
        name: "Vespasiano",
        slug: "vespasiano",
        description: "Centro, Residencial, Morro Alto",
        lineCount: 12,
        color: "secondary",
        isActive: true,
      },
      {
        name: "Pedro Leopoldo",
        slug: "pedro-leopoldo",
        description: "Centro, Nova Prata, Fidalgo",
        lineCount: 9,
        color: "accent",
        isActive: true,
      },
      {
        name: "Lagoa Santa",
        slug: "lagoa-santa",
        description: "Centro, Aeroporto, Palmital",
        lineCount: 11,
        color: "muted",
        isActive: true,
      },
      {
        name: "Ribeirão das Neves",
        slug: "ribeirao-neves",
        description: "Centro, Veneza, Justinópolis",
        lineCount: 15,
        color: "primary",
        isActive: true,
      },
      {
        name: "Santa Luzia",
        slug: "santa-luzia",
        description: "Centro, Duquesa, São Benedito",
        lineCount: 10,
        color: "secondary",
        isActive: true,
      },
    ];

    regions.forEach(region => {
      const id = randomUUID();
      this.cityRegions.set(id, {
        ...region,
        id,
        color: region.color ?? "primary",
        isActive: region.isActive ?? true,
        description: region.description ?? null,
        lineCount: region.lineCount ?? 0,
      });
    });

    const lines: InsertBusLine[] = [
      // São José da Lapa
      {
        number: "201",
        name: "Terminal BH Norte - São José da Lapa",
        route: "Via Centro, Eldorado",
        frequency: "15-20 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "202",
        name: "São José da Lapa - Shopping Norte",
        route: "Via Industrial, Eldorado",
        frequency: "20-25 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "203",
        name: "Lapa Centro - Terminal Barreiro",
        route: "Via BR-040, Contagem",
        frequency: "30-35 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "204",
        name: "Eldorado - Estação São Gabriel",
        route: "Via Centro da Lapa",
        frequency: "25-30 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "205",
        name: "Industrial Lapa - BH Centro",
        route: "Via Av. Cristiano Machado",
        frequency: "20-25 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "206",
        name: "Lapa - Hospital João XXIII",
        route: "Via Anel Rodoviário",
        frequency: "35-40 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "207",
        name: "São José da Lapa - UFMG",
        route: "Via Pampulha",
        frequency: "40-45 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },
      {
        number: "208",
        name: "Lapa Circular - Bairros",
        route: "Circular pelos bairros",
        frequency: "30-35 min",
        region: "sao-jose-lapa",
        color: "primary",
        isActive: true,
      },

      // Vespasiano
      {
        number: "301",
        name: "Vespasiano Centro - Terminal BH Norte",
        route: "Via Morro Alto",
        frequency: "15-20 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "302",
        name: "Vespasiano - Shopping Norte",
        route: "Via Ribeirão das Neves",
        frequency: "20-25 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "303",
        name: "Morro Alto - BH Centro",
        route: "Via Av. Cristiano Machado",
        frequency: "25-30 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "304",
        name: "Vespasiano - Estação Pampulha",
        route: "Via Ribeirão das Neves",
        frequency: "30-35 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "305",
        name: "Angicos - Terminal Barreiro",
        route: "Via Centro de Vespasiano",
        frequency: "35-40 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "306",
        name: "Vespasiano - Hospital São João de Deus",
        route: "Via Centro",
        frequency: "40-45 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "307",
        name: "Jardim Cambuí - UFMG",
        route: "Via Pampulha",
        frequency: "45-50 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "308",
        name: "Vespasiano Circular",
        route: "Circular urbano",
        frequency: "25-30 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "309",
        name: "Morro Alto - Shopping Del Rey",
        route: "Via BR-040",
        frequency: "50-60 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "310",
        name: "Vespasiano - Aeroporto Confins",
        route: "Via Lagoa Santa",
        frequency: "60-70 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "311",
        name: "Nova União - Terminal Norte",
        route: "Via Centro Vespasiano",
        frequency: "30-35 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },
      {
        number: "312",
        name: "Vespasiano - Estação São Gabriel",
        route: "Via Ribeirão das Neves",
        frequency: "35-40 min",
        region: "vespasiano",
        color: "secondary",
        isActive: true,
      },

      // Pedro Leopoldo
      {
        number: "401",
        name: "Pedro Leopoldo - BH Centro",
        route: "Via Vespasiano, Lagoa Santa",
        frequency: "30-35 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "402",
        name: "Nova Prata - Terminal BH Norte",
        route: "Via Centro Pedro Leopoldo",
        frequency: "25-30 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "403",
        name: "Pedro Leopoldo - Shopping Norte",
        route: "Via Vespasiano",
        frequency: "35-40 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "404",
        name: "Fidalgo - Aeroporto Confins",
        route: "Via Lagoa Santa",
        frequency: "40-45 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "405",
        name: "Pedro Leopoldo - UFMG",
        route: "Via Pampulha, Lagoa Santa",
        frequency: "50-60 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "406",
        name: "Quinta do Sumidouro - BH Centro",
        route: "Via Centro Pedro Leopoldo",
        frequency: "45-50 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "407",
        name: "Pedro Leopoldo Circular",
        route: "Circular urbano",
        frequency: "30-35 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "408",
        name: "Nova Prata - Hospital João XXIII",
        route: "Via BH Centro",
        frequency: "60-70 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },
      {
        number: "409",
        name: "Pedro Leopoldo - Terminal Barreiro",
        route: "Via Contagem",
        frequency: "70-80 min",
        region: "pedro-leopoldo",
        color: "accent",
        isActive: true,
      },

      // Lagoa Santa
      {
        number: "501",
        name: "Lagoa Santa - Aeroporto Confins",
        route: "Via Centro, Palmital",
        frequency: "20-25 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "502",
        name: "Palmital - BH Centro",
        route: "Via Av. Cristiano Machado",
        frequency: "35-40 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "503",
        name: "Lagoa Santa - Terminal BH Norte",
        route: "Via Vespasiano",
        frequency: "30-35 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "504",
        name: "Centro Lagoa Santa - Shopping Norte",
        route: "Via Pedro Leopoldo",
        frequency: "40-45 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "505",
        name: "Aeroporto - UFMG",
        route: "Via Pampulha",
        frequency: "45-50 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "506",
        name: "Lagoa Santa - Hospital São João de Deus",
        route: "Via Vespasiano",
        frequency: "50-60 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "507",
        name: "Palmital - Terminal Barreiro",
        route: "Via Contagem",
        frequency: "60-70 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "508",
        name: "Lagoa Santa Circular",
        route: "Circular urbano",
        frequency: "25-30 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "509",
        name: "Aeroporto Express - BH Centro",
        route: "Via Anel Rodoviário",
        frequency: "30-40 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "510",
        name: "Lagoa Santa - Shopping Del Rey",
        route: "Via BR-040",
        frequency: "55-65 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },
      {
        number: "511",
        name: "Confins - Estação São Gabriel",
        route: "Via Centro Lagoa Santa",
        frequency: "40-50 min",
        region: "lagoa-santa",
        color: "muted",
        isActive: true,
      },

      // Ribeirão das Neves
      {
        number: "601",
        name: "Ribeirão das Neves - Terminal BH Norte",
        route: "Via Vespasiano",
        frequency: "15-20 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "602",
        name: "Justinópolis - BH Centro",
        route: "Via Av. Cristiano Machado",
        frequency: "20-25 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "603",
        name: "Veneza - Shopping Norte",
        route: "Via Centro Ribeirão",
        frequency: "25-30 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "604",
        name: "Ribeirão Centro - Estação Pampulha",
        route: "Via Vespasiano",
        frequency: "30-35 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "605",
        name: "Justinópolis - UFMG",
        route: "Via Pampulha",
        frequency: "40-45 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "606",
        name: "Ribeirão - Hospital João XXIII",
        route: "Via BH Centro",
        frequency: "45-50 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "607",
        name: "Veneza - Terminal Barreiro",
        route: "Via Contagem",
        frequency: "50-60 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "608",
        name: "Ribeirão Circular Norte",
        route: "Circular bairros norte",
        frequency: "20-25 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "609",
        name: "Ribeirão Circular Sul",
        route: "Circular bairros sul",
        frequency: "25-30 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "610",
        name: "Justinópolis - Aeroporto Confins",
        route: "Via Lagoa Santa",
        frequency: "60-70 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "611",
        name: "Ribeirão - Shopping Del Rey",
        route: "Via BR-040",
        frequency: "55-65 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "612",
        name: "Veneza - Estação São Gabriel",
        route: "Via Centro Ribeirão",
        frequency: "35-40 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "613",
        name: "Ribeirão Express - BH Centro",
        route: "Via Anel Rodoviário",
        frequency: "25-35 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "614",
        name: "Justinópolis - Terminal Norte",
        route: "Via Vespasiano",
        frequency: "30-35 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },
      {
        number: "615",
        name: "Ribeirão - Hospital São João de Deus",
        route: "Via Vespasiano",
        frequency: "40-50 min",
        region: "ribeirao-neves",
        color: "primary",
        isActive: true,
      },

      // Santa Luzia
      {
        number: "701",
        name: "Santa Luzia - BH Centro",
        route: "Via Av. Cristiano Machado",
        frequency: "20-25 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "702",
        name: "Duquesa - Terminal BH Norte",
        route: "Via Centro Santa Luzia",
        frequency: "25-30 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "703",
        name: "São Benedito - Shopping Norte",
        route: "Via Ribeirão das Neves",
        frequency: "30-35 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "704",
        name: "Santa Luzia - Estação Pampulha",
        route: "Via UFMG",
        frequency: "35-40 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "705",
        name: "Duquesa - Hospital João XXIII",
        route: "Via BH Centro",
        frequency: "40-45 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "706",
        name: "Santa Luzia - Terminal Barreiro",
        route: "Via Contagem",
        frequency: "50-60 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "707",
        name: "São Benedito - Aeroporto Confins",
        route: "Via Lagoa Santa",
        frequency: "70-80 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "708",
        name: "Santa Luzia Circular",
        route: "Circular urbano",
        frequency: "25-30 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "709",
        name: "Duquesa - Shopping Del Rey",
        route: "Via BR-040",
        frequency: "60-70 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
      {
        number: "710",
        name: "Santa Luzia - Estação São Gabriel",
        route: "Via Ribeirão das Neves",
        frequency: "45-50 min",
        region: "santa-luzia",
        color: "secondary",
        isActive: true,
      },
    ];

    lines.forEach(line => {
      const id = randomUUID();
      this.busLines.set(id, {
        ...line,
        id,
        color: line.color ?? "primary",
        isActive: line.isActive ?? true,
        createdAt: new Date(),
      });

      // Create sample schedules for each line
      const schedules = [
        "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00",
        "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00",
        "13:30", "14:00", "14:35", "15:05", "15:35", "16:00", "16:30", "17:00",
        "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00"
      ];

      schedules.forEach(time => {
        const scheduleId = randomUUID();
        this.busSchedules.set(scheduleId, {
          id: scheduleId,
          lineId: id,
          departureTime: time,
          direction: `${line.name}`,
          weekdays: true,
          weekends: time >= "07:00" && time <= "19:00", // Weekend service more limited
          isActive: true,
        });
      });
    });

    // Add comprehensive live updates
    const updates: InsertLiveUpdate[] = [
      {
        title: "Trânsito Intenso BR-040",
        message: "Linhas 201, 202, 203 - Atraso de 10-15 minutos devido ao trânsito intenso na BR-040, próximo ao trevo de São José da Lapa",
        type: "warning",
        priority: 1,
        isActive: true,
      },
      {
        title: "Obras Av. Cristiano Machado",
        message: "Desvio ativo - Linhas 303, 502, 602 seguindo rota alternativa devido às obras na Av. Cristiano Machado, entre os kms 15-18",
        type: "info",
        priority: 2,
        isActive: true,
      },
      {
        title: "Aeroporto Confins Normalizado",
        message: "Operação normal - Linhas 501, 404, 505, 610 operando conforme cronograma para o Aeroporto Internacional de Confins",
        type: "success",
        priority: 3,
        isActive: true,
      },
      {
        title: "Terminal BH Norte - Lotação Alta",
        message: "Terminal BH Norte com grande movimento - Linhas 301, 601, 503, 702 com intervalos reduzidos para atender a demanda",
        type: "info",
        priority: 4,
        isActive: true,
      },
      {
        title: "Linha 613 Express - Serviço Especial",
        message: "Ribeirão Express operando com paradas limitadas para maior agilidade no trajeto ao centro de BH",
        type: "success",
        priority: 5,
        isActive: true,
      },
      {
        title: "Chuva Região Norte",
        message: "Chuva moderada na região - Todas as linhas mantêm operação normal com atenção redobrada à segurança",
        type: "warning",
        priority: 6,
        isActive: true,
      },
      {
        title: "Shopping Norte - Evento Especial",
        message: "Linhas 202, 302, 403, 504, 603 com reforço de frota devido ao evento no Shopping Norte até 22h",
        type: "info",
        priority: 7,
        isActive: true,
      },
      {
        title: "UFMG - Período de Provas",
        message: "Linhas universitárias 207, 307, 405, 505, 704 com horários estendidos durante o período de provas da UFMG",
        type: "success",
        priority: 8,
        isActive: true,
      },
    ];

    updates.forEach(update => {
      const id = randomUUID();
      this.liveUpdates.set(id, {
        ...update,
        id,
        isActive: update.isActive ?? true,
        lineId: update.lineId ?? null,
        priority: update.priority ?? 1,
        createdAt: new Date(),
      });
    });
  }

  async getBusLines(): Promise<BusLine[]> {
    return Array.from(this.busLines.values()).filter(line => line.isActive);
  }

  async getBusLine(id: string): Promise<BusLine | undefined> {
    return this.busLines.get(id);
  }

  async getBusLineWithSchedules(id: string): Promise<BusLineWithSchedules | undefined> {
    const line = this.busLines.get(id);
    if (!line) return undefined;

    const schedules = await this.getSchedulesForLine(id);
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    // Find next departure
    const nextDeparture = schedules
      .filter(s => s.departureTime > currentTime)
      .sort((a, b) => a.departureTime.localeCompare(b.departureTime))[0]?.departureTime;

    return {
      ...line,
      schedules,
      nextDeparture,
    };
  }

  async createBusLine(line: InsertBusLine): Promise<BusLine> {
    const id = randomUUID();
    const newLine: BusLine = {
      ...line,
      id,
      color: line.color ?? "primary",
      isActive: line.isActive ?? true,
      createdAt: new Date(),
    };
    this.busLines.set(id, newLine);
    return newLine;
  }

  async searchBusLines(query: string): Promise<BusLine[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.busLines.values()).filter(line =>
      line.isActive && (
        line.name.toLowerCase().includes(lowerQuery) ||
        line.number.toLowerCase().includes(lowerQuery) ||
        line.route.toLowerCase().includes(lowerQuery)
      )
    );
  }

  async getSchedulesForLine(lineId: string): Promise<BusSchedule[]> {
    return Array.from(this.busSchedules.values()).filter(
      schedule => schedule.lineId === lineId && schedule.isActive
    ).sort((a, b) => a.departureTime.localeCompare(b.departureTime));
  }

  async createSchedule(schedule: InsertBusSchedule): Promise<BusSchedule> {
    const id = randomUUID();
    const newSchedule: BusSchedule = {
      ...schedule,
      id,
      isActive: schedule.isActive ?? true,
      weekdays: schedule.weekdays ?? true,
      weekends: schedule.weekends ?? false,
    };
    this.busSchedules.set(id, newSchedule);
    return newSchedule;
  }

  async getLiveUpdates(): Promise<LiveUpdate[]> {
    return Array.from(this.liveUpdates.values()).sort((a, b) => 
      (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }

  async getActiveLiveUpdates(): Promise<LiveUpdate[]> {
    return Array.from(this.liveUpdates.values())
      .filter(update => update.isActive)
      .sort((a, b) => (a.priority || 0) - (b.priority || 0));
  }

  async createLiveUpdate(update: InsertLiveUpdate): Promise<LiveUpdate> {
    const id = randomUUID();
    const newUpdate: LiveUpdate = {
      ...update,
      id,
      isActive: update.isActive ?? true,
      lineId: update.lineId ?? null,
      priority: update.priority ?? 1,
      createdAt: new Date(),
    };
    this.liveUpdates.set(id, newUpdate);
    return newUpdate;
  }

  async getCityRegions(): Promise<CityRegion[]> {
    return Array.from(this.cityRegions.values()).filter(region => region.isActive);
  }

  async getCityRegionWithLines(slug: string): Promise<CityRegionWithLines | undefined> {
    const region = Array.from(this.cityRegions.values()).find(r => r.slug === slug);
    if (!region) return undefined;

    const lines = Array.from(this.busLines.values()).filter(
      line => line.region === slug && line.isActive
    );

    return {
      ...region,
      lines,
    };
  }

  async createCityRegion(region: InsertCityRegion): Promise<CityRegion> {
    const id = randomUUID();
    const newRegion: CityRegion = {
      ...region,
      id,
    };
    this.cityRegions.set(id, newRegion);
    return newRegion;
  }

  async getUserFavorites(userId: string): Promise<UserFavorite[]> {
    return Array.from(this.userFavorites.values()).filter(
      favorite => favorite.userId === userId
    );
  }

  async addToFavorites(favorite: InsertUserFavorite): Promise<UserFavorite> {
    const id = randomUUID();
    const newFavorite: UserFavorite = {
      ...favorite,
      id,
      createdAt: new Date(),
    };
    this.userFavorites.set(id, newFavorite);
    return newFavorite;
  }

  async removeFromFavorites(userId: string, lineId: string): Promise<boolean> {
    const favorite = Array.from(this.userFavorites.entries()).find(
      ([, fav]) => fav.userId === userId && fav.lineId === lineId
    );
    
    if (favorite) {
      this.userFavorites.delete(favorite[0]);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
