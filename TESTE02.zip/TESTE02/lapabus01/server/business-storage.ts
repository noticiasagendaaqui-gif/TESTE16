import type { 
  City, 
  InsertCity, 
  Business, 
  InsertBusiness, 
  CityWithBusinesses, 
  BusinessCategory, 
  InsertBusinessCategory 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IBusinessStorage {
  // Cities
  getCities(): Promise<City[]>;
  getCity(slug: string): Promise<City | undefined>;
  getCityWithBusinesses(slug: string): Promise<CityWithBusinesses | undefined>;
  createCity(city: InsertCity): Promise<City>;
  
  // Businesses
  getBusinesses(): Promise<Business[]>;
  getBusinessesByCity(cityId: string): Promise<Business[]>;
  getBusinessesByCategory(category: string): Promise<Business[]>;
  getBusinessesByCityAndCategory(cityId: string, category: string): Promise<Business[]>;
  getBusiness(id: string): Promise<Business | undefined>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  searchBusinesses(query: string, cityId?: string): Promise<Business[]>;
  
  // Business Categories
  getBusinessCategories(): Promise<BusinessCategory[]>;
  getBusinessCategory(slug: string): Promise<BusinessCategory | undefined>;
  createBusinessCategory(category: InsertBusinessCategory): Promise<BusinessCategory>;
}

export class MemBusinessStorage implements IBusinessStorage {
  private cities: Map<string, City> = new Map();
  private businesses: Map<string, Business> = new Map();
  private businessCategories: Map<string, BusinessCategory> = new Map();

  constructor() {
    this.initializeCategories();
    this.initializeData();
  }

  private initializeCategories() {
    const categoriesData: InsertBusinessCategory[] = [
      {
        name: "Transporte",
        slug: "transport",
        icon: "Bus",
        color: "blue",
        description: "Empresas de transporte público, táxi, ônibus e fretamento",
        isActive: true,
      },
      {
        name: "Restaurantes",
        slug: "restaurants",
        icon: "UtensilsCrossed",
        color: "orange",
        description: "Restaurantes, lanchonetes, pizzarias e delivery",
        isActive: true,
      },
      {
        name: "Hotéis e Pousadas",
        slug: "hotels",
        icon: "Bed",
        color: "purple",
        description: "Hotéis, pousadas, motéis e hospedagem",
        isActive: true,
      },
      {
        name: "Saúde",
        slug: "health",
        icon: "Heart",
        color: "red",
        description: "Farmácias, clínicas, laboratórios e consultórios",
        isActive: true,
      },
      {
        name: "Serviços",
        slug: "services",
        icon: "Wrench",
        color: "green",
        description: "Oficinas, salões, lavanderias e serviços gerais",
        isActive: true,
      },
      {
        name: "Comércio",
        slug: "retail",
        icon: "ShoppingBag",
        color: "indigo",
        description: "Lojas, supermercados, farmácias e varejo",
        isActive: true,
      },
      {
        name: "Educação",
        slug: "education",
        icon: "GraduationCap",
        color: "cyan",
        description: "Escolas, cursos, universidades e ensino",
        isActive: true,
      },
      {
        name: "Lazer e Turismo",
        slug: "leisure",
        icon: "Camera",
        color: "pink",
        description: "Pontos turísticos, parques, eventos e entretenimento",
        isActive: true,
      },
    ];

    categoriesData.forEach(categoryData => {
      const category: BusinessCategory = {
        id: randomUUID(),
        ...categoryData,
      };
      this.businessCategories.set(category.id, category);
    });
  }

  private initializeData() {
    // Initialize cities in BH Norte region
    const citiesData: InsertCity[] = [
      {
        name: "São José da Lapa",
        slug: "sao-jose-da-lapa",
        state: "MG",
        population: 21000,
        distanceFromBH: 32,
        description: "Município industrial da região metropolitana de BH, conhecido por suas indústrias e proximidade com o aeroporto.",
        banner: "/banners/sao-jose-lapa.jpg",
        coordinates: "-19.7850,-44.1450",
        isActive: true,
      },
      {
        name: "Vespasiano",
        slug: "vespasiano",
        state: "MG", 
        population: 135000,
        distanceFromBH: 25,
        description: "Cidade em franco crescimento, com diversos bairros residenciais e boa infraestrutura de transporte.",
        banner: "/banners/vespasiano.jpg",
        coordinates: "-19.6920,-44.0080",
        isActive: true,
      },
      {
        name: "Pedro Leopoldo",
        slug: "pedro-leopoldo",
        state: "MG",
        population: 65000,
        distanceFromBH: 40,
        description: "Cidade histórica conhecida pelo sítio arqueológico de Luzia e pela tradicional Festa de Reis.",
        banner: "/banners/pedro-leopoldo.jpg",
        coordinates: "-19.6180,-44.0420",
        isActive: true,
      },
      {
        name: "Lagoa Santa",
        slug: "lagoa-santa",
        state: "MG",
        population: 70000,
        distanceFromBH: 35,
        description: "Famosa por suas lagoas naturais e sítios arqueológicos, destino turístico da região metropolitana.",
        banner: "/banners/lagoa-santa.jpg",
        coordinates: "-19.6350,-43.8920",
        isActive: true,
      },
    ];

    // Create cities
    citiesData.forEach(cityData => {
      const city: City = {
        id: randomUUID(),
        ...cityData,
        createdAt: new Date(),
      };
      this.cities.set(city.id, city);
    });

    // Initialize businesses for each city
    this.initializeBusinesses();
  }

  private initializeBusinesses() {
    const saoJoseCity = Array.from(this.cities.values()).find(c => c.slug === "sao-jose-da-lapa");
    const vespasianoCity = Array.from(this.cities.values()).find(c => c.slug === "vespasiano");
    const pedroLeopoldoCity = Array.from(this.cities.values()).find(c => c.slug === "pedro-leopoldo");
    const lagoaSantaCity = Array.from(this.cities.values()).find(c => c.slug === "lagoa-santa");

    const businessesData: InsertBusiness[] = [
      // São José da Lapa - Transporte
      {
        cityId: saoJoseCity?.id || "",
        name: "Viação União Norte",
        slug: "viacao-uniao-norte",
        category: "transport",
        subcategory: "bus",
        phone: "(31) 3689-1234",
        whatsapp: "5531368912234",
        email: "contato@viacaouniaonorte.com.br",
        website: "https://viacaouniaonorte.com.br",
        address: "Rua Principal, 1500",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7850,-44.1450",
        banner: "/banners/company-uniao-norte.jpg",
        images: ["/images/uniao-norte-1.jpg", "/images/uniao-norte-2.jpg"],
        description: "Empresa de transporte coletivo especializada em linhas metropolitanas. Atende São José da Lapa e região há mais de 20 anos.",
        services: ["Transporte Urbano", "Linhas Metropolitanas", "Fretamento", "Turismo"],
        workingHours: {
          "monday": { "open": "05:00", "close": "23:00" },
          "tuesday": { "open": "05:00", "close": "23:00" },
          "wednesday": { "open": "05:00", "close": "23:00" },
          "thursday": { "open": "05:00", "close": "23:00" },
          "friday": { "open": "05:00", "close": "23:00" },
          "saturday": { "open": "06:00", "close": "22:00" },
          "sunday": { "open": "07:00", "close": "21:00" }
        },
        priceRange: "$$",
        rating: 4,
        reviewCount: 89,
        isVerified: true,
        isActive: true,
      },
      
      // São José da Lapa - Restaurantes
      {
        cityId: saoJoseCity?.id || "",
        name: "Pizzaria do Zé",
        slug: "pizzaria-do-ze",
        category: "restaurants",
        subcategory: "pizza",
        phone: "(31) 3689-8888",
        whatsapp: "5531368988888",
        address: "Rua das Flores, 245",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7840,-44.1440",
        banner: "/banners/pizzaria-ze.jpg",
        description: "Pizzaria tradicional com mais de 15 anos servindo as melhores pizzas da região.",
        services: ["Pizza", "Delivery", "Refrigerantes", "Sobremesas"],
        workingHours: {
          "tuesday": { "open": "18:00", "close": "23:00" },
          "wednesday": { "open": "18:00", "close": "23:00" },
          "thursday": { "open": "18:00", "close": "23:00" },
          "friday": { "open": "18:00", "close": "24:00" },
          "saturday": { "open": "18:00", "close": "24:00" },
          "sunday": { "open": "18:00", "close": "23:00" }
        },
        priceRange: "$$",
        rating: 5,
        reviewCount: 127,
        isVerified: true,
        isActive: true,
      },
      
      // São José da Lapa - Saúde
      {
        cityId: saoJoseCity?.id || "",
        name: "Farmácia Popular",
        slug: "farmacia-popular",
        category: "health",
        subcategory: "pharmacy",
        phone: "(31) 3689-2200",
        whatsapp: "5531368922200",
        address: "Praça Central, 89",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7845,-44.1445",
        banner: "/banners/farmacia-popular.jpg",
        description: "Farmácia completa com medicamentos, perfumaria e conveniência. Atendimento 24h.",
        services: ["Medicamentos", "Perfumaria", "Conveniência", "Delivery"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$",
        rating: 4,
        reviewCount: 78,
        isVerified: true,
        isActive: true,
      },
      
      // Vespasiano - Transporte
      {
        cityId: vespasianoCity?.id || "",
        name: "Expresso Vespasiano",
        slug: "expresso-vespasiano",
        category: "transport",
        subcategory: "bus",
        phone: "(31) 3621-9000",
        whatsapp: "5531362190000",
        email: "sac@expressovespasiano.com.br",
        website: "https://expressovespasiano.com.br",
        address: "Rua das Palmeiras, 2100",
        neighborhood: "Centro",
        postalCode: "33200-000",
        coordinates: "-19.6920,-44.0080",
        banner: "/banners/company-expresso-vespasiano.jpg",
        description: "Principal empresa de transporte de Vespasiano, conectando a cidade a Belo Horizonte e região metropolitana.",
        services: ["Transporte Metropolitano", "Linhas Expressas", "Transporte Executivo", "Fretamento"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$$$",
        rating: 4,
        reviewCount: 234,
        isVerified: true,
        isActive: true,
      },
      
      // Vespasiano - Restaurante
      {
        cityId: vespasianoCity?.id || "",
        name: "Restaurante Mineiro da Vó",
        slug: "restaurante-mineiro-da-vo",
        category: "restaurants",
        subcategory: "mineira",
        phone: "(31) 3621-5555",
        whatsapp: "5531362155555",
        address: "Avenida Principal, 567",
        neighborhood: "Centro",
        postalCode: "33200-000",
        coordinates: "-19.6925,-44.0085",
        banner: "/banners/restaurante-vo.jpg",
        description: "Comida mineira tradicional com tempero caseiro e ambiente acolhedor.",
        services: ["Almoço", "Delivery", "Marmita", "Eventos"],
        workingHours: {
          "monday": { "open": "11:00", "close": "15:00" },
          "tuesday": { "open": "11:00", "close": "15:00" },
          "wednesday": { "open": "11:00", "close": "15:00" },
          "thursday": { "open": "11:00", "close": "15:00" },
          "friday": { "open": "11:00", "close": "15:00" },
          "saturday": { "open": "11:00", "close": "16:00" },
          "sunday": { "open": "11:00", "close": "16:00" }
        },
        priceRange: "$$",
        rating: 5,
        reviewCount: 156,
        isVerified: true,
        isActive: true,
      },
      
      // Pedro Leopoldo - Turismo
      {
        cityId: pedroLeopoldoCity?.id || "",
        name: "Museu Arqueológico de Pedro Leopoldo",
        slug: "museu-arqueologico",
        category: "leisure",
        subcategory: "museum",
        phone: "(31) 3661-2851",
        email: "contato@museuarqueologico.com.br",
        website: "https://museuarqueologico.com.br",
        address: "Rua do Museu, 100",
        neighborhood: "Centro",
        postalCode: "33600-000",
        coordinates: "-19.6180,-44.0420",
        banner: "/banners/museu-pedro-leopoldo.jpg",
        description: "Museu com os fósseis mais antigos das Américas, incluindo Luzia. Patrimônio arqueológico nacional.",
        services: ["Visitas Guiadas", "Exposições", "Educação", "Pesquisa"],
        workingHours: {
          "tuesday": { "open": "08:00", "close": "17:00" },
          "wednesday": { "open": "08:00", "close": "17:00" },
          "thursday": { "open": "08:00", "close": "17:00" },
          "friday": { "open": "08:00", "close": "17:00" },
          "saturday": { "open": "08:00", "close": "17:00" },
          "sunday": { "open": "08:00", "close": "17:00" }
        },
        priceRange: "$",
        rating: 5,
        reviewCount: 445,
        isVerified: true,
        isActive: true,
      },
      
      // Lagoa Santa - Turismo
      {
        cityId: lagoaSantaCity?.id || "",
        name: "Pousada Lagoa Azul",
        slug: "pousada-lagoa-azul",
        category: "hotels",
        subcategory: "pousada",
        phone: "(31) 3681-4400",
        whatsapp: "5531368144400",
        email: "reservas@pousadalagoaazul.com.br",
        website: "https://pousadalagoaazul.com.br",
        address: "Rua da Lagoa, 200",
        neighborhood: "Centro",
        postalCode: "33400-000",
        coordinates: "-19.6350,-43.8920",
        banner: "/banners/pousada-lagoa-azul.jpg",
        description: "Pousada charmosa à beira da lagoa, ideal para relaxar e contemplar a natureza.",
        services: ["Hospedagem", "Café da Manhã", "Wi-Fi", "Estacionamento"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$$$",
        rating: 4,
        reviewCount: 189,
        isVerified: true,
        isActive: true,
      },

      // Mais restaurantes
      {
        cityId: saoJoseCity?.id || "",
        name: "Churrascaria Gaúcha",
        slug: "churrascaria-gaucha",
        category: "restaurants",
        subcategory: "churrasco",
        phone: "(31) 3689-7777",
        whatsapp: "5531368977777",
        address: "Rua das Acácias, 890",
        neighborhood: "Industrial",
        postalCode: "33350-000",
        coordinates: "-19.7860,-44.1460",
        description: "Churrascaria tradicional com carnes nobres e buffet variado.",
        services: ["Rodízio", "Buffet", "Eventos", "Estacionamento"],
        workingHours: {
          "monday": { "open": "11:00", "close": "15:00" },
          "tuesday": { "open": "11:00", "close": "15:00" },
          "wednesday": { "open": "11:00", "close": "15:00" },
          "thursday": { "open": "11:00", "close": "15:00" },
          "friday": { "open": "11:00", "close": "23:00" },
          "saturday": { "open": "11:00", "close": "23:00" },
          "sunday": { "open": "11:00", "close": "23:00" }
        },
        priceRange: "$$$",
        rating: 4,
        reviewCount: 234,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: vespasianoCity?.id || "",
        name: "Lanchonete do João",
        slug: "lanchonete-do-joao",
        category: "restaurants",
        subcategory: "lanchonete",
        phone: "(31) 3621-3333",
        whatsapp: "5531362133333",
        address: "Rua Comercial, 123",
        neighborhood: "Centro",
        postalCode: "33200-000",
        coordinates: "-19.6930,-44.0090",
        description: "Lanchonete tradicional com lanches artesanais e sucos naturais.",
        services: ["Lanches", "Sucos", "Delivery", "Açaí"],
        workingHours: {
          "monday": { "open": "06:00", "close": "22:00" },
          "tuesday": { "open": "06:00", "close": "22:00" },
          "wednesday": { "open": "06:00", "close": "22:00" },
          "thursday": { "open": "06:00", "close": "22:00" },
          "friday": { "open": "06:00", "close": "23:00" },
          "saturday": { "open": "06:00", "close": "23:00" },
          "sunday": { "open": "08:00", "close": "20:00" }
        },
        priceRange: "$",
        rating: 4,
        reviewCount: 98,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: pedroLeopoldoCity?.id || "",
        name: "Restaurante Sabor Mineiro",
        slug: "restaurante-sabor-mineiro",
        category: "restaurants",
        subcategory: "mineira",
        phone: "(31) 3661-4444",
        whatsapp: "5531366144444",
        address: "Praça da Matriz, 45",
        neighborhood: "Centro",
        postalCode: "33600-000",
        coordinates: "-19.6190,-44.0430",
        description: "Culinária mineira autêntica com pratos típicos e ambiente familiar.",
        services: ["Almoço", "Marmitas", "Eventos", "Buffet"],
        workingHours: {
          "monday": { "open": "11:00", "close": "15:00" },
          "tuesday": { "open": "11:00", "close": "15:00" },
          "wednesday": { "open": "11:00", "close": "15:00" },
          "thursday": { "open": "11:00", "close": "15:00" },
          "friday": { "open": "11:00", "close": "15:00" },
          "saturday": { "open": "11:00", "close": "16:00" },
          "sunday": { "open": "11:00", "close": "16:00" }
        },
        priceRange: "$$",
        rating: 5,
        reviewCount: 167,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: lagoaSantaCity?.id || "",
        name: "Bistrô da Lagoa",
        slug: "bistro-da-lagoa",
        category: "restaurants",
        subcategory: "bistro",
        phone: "(31) 3681-5555",
        whatsapp: "5531368155555",
        address: "Marginal da Lagoa, 78",
        neighborhood: "Lagoa",
        postalCode: "33400-000",
        coordinates: "-19.6360,-43.8930",
        description: "Bistrô com vista para a lagoa, especializado em pratos gourmet e drinks.",
        services: ["Almoço", "Jantar", "Drinks", "Vista Panorâmica"],
        workingHours: {
          "tuesday": { "open": "12:00", "close": "22:00" },
          "wednesday": { "open": "12:00", "close": "22:00" },
          "thursday": { "open": "12:00", "close": "22:00" },
          "friday": { "open": "12:00", "close": "24:00" },
          "saturday": { "open": "12:00", "close": "24:00" },
          "sunday": { "open": "12:00", "close": "20:00" }
        },
        priceRange: "$$$",
        rating: 4,
        reviewCount: 89,
        isVerified: true,
        isActive: true,
      },

      // Mais hotéis
      {
        cityId: saoJoseCity?.id || "",
        name: "Hotel Executivo",
        slug: "hotel-executivo",
        category: "hotels",
        subcategory: "hotel",
        phone: "(31) 3689-6000",
        whatsapp: "5531368960000",
        email: "reservas@hotelexecutivo.com.br",
        address: "Avenida Industrial, 1200",
        neighborhood: "Industrial",
        postalCode: "33350-000",
        coordinates: "-19.7870,-44.1470",
        description: "Hotel moderno com foco em hospedagem executiva e eventos corporativos.",
        services: ["Hospedagem", "Eventos", "Wi-Fi", "Business Center"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$$$$",
        rating: 4,
        reviewCount: 156,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: vespasianoCity?.id || "",
        name: "Pousada Família",
        slug: "pousada-familia",
        category: "hotels",
        subcategory: "pousada",
        phone: "(31) 3621-7777",
        whatsapp: "5531362177777",
        address: "Rua Residencial, 456",
        neighborhood: "Residencial",
        postalCode: "33200-000",
        coordinates: "-19.6940,-44.0100",
        description: "Pousada aconchegante ideal para famílias e grupos.",
        services: ["Hospedagem", "Café da Manhã", "Playground", "Churrasqueira"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$$",
        rating: 4,
        reviewCount: 78,
        isVerified: true,
        isActive: true,
      },

      // Mais saúde
      {
        cityId: vespasianoCity?.id || "",
        name: "Clínica Médica Norte",
        slug: "clinica-medica-norte",
        category: "health",
        subcategory: "clinic",
        phone: "(31) 3621-8888",
        whatsapp: "5531362188888",
        email: "contato@clinicanorte.com.br",
        address: "Avenida Saúde, 789",
        neighborhood: "Centro",
        postalCode: "33200-000",
        coordinates: "-19.6950,-44.0110",
        description: "Clínica médica com especialidades diversas e atendimento de qualidade.",
        services: ["Consultas", "Exames", "Especialidades", "Emergência"],
        workingHours: {
          "monday": { "open": "07:00", "close": "18:00" },
          "tuesday": { "open": "07:00", "close": "18:00" },
          "wednesday": { "open": "07:00", "close": "18:00" },
          "thursday": { "open": "07:00", "close": "18:00" },
          "friday": { "open": "07:00", "close": "18:00" },
          "saturday": { "open": "08:00", "close": "12:00" }
        },
        priceRange: "$$",
        rating: 4,
        reviewCount: 134,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: pedroLeopoldoCity?.id || "",
        name: "Laboratório Análises Clínicas",
        slug: "laboratorio-analises",
        category: "health",
        subcategory: "laboratory",
        phone: "(31) 3661-9999",
        whatsapp: "5531366199999",
        address: "Rua da Saúde, 321",
        neighborhood: "Centro",
        postalCode: "33600-000",
        coordinates: "-19.6200,-44.0440",
        description: "Laboratório completo com exames diversos e resultados rápidos.",
        services: ["Exames de Sangue", "Exames de Urina", "Check-up", "Coleta Domiciliar"],
        workingHours: {
          "monday": { "open": "06:00", "close": "16:00" },
          "tuesday": { "open": "06:00", "close": "16:00" },
          "wednesday": { "open": "06:00", "close": "16:00" },
          "thursday": { "open": "06:00", "close": "16:00" },
          "friday": { "open": "06:00", "close": "16:00" },
          "saturday": { "open": "06:00", "close": "12:00" }
        },
        priceRange: "$",
        rating: 5,
        reviewCount: 89,
        isVerified: true,
        isActive: true,
      },

      // Serviços
      {
        cityId: saoJoseCity?.id || "",
        name: "Auto Center São José",
        slug: "auto-center-sao-jose",
        category: "services",
        subcategory: "automotive",
        phone: "(31) 3689-1111",
        whatsapp: "5531368911111",
        address: "Rua dos Mecânicos, 567",
        neighborhood: "Industrial",
        postalCode: "33350-000",
        coordinates: "-19.7880,-44.1480",
        description: "Oficina completa com serviços automotivos e peças originais.",
        services: ["Mecânica Geral", "Elétrica", "Pintura", "Alinhamento"],
        workingHours: {
          "monday": { "open": "08:00", "close": "18:00" },
          "tuesday": { "open": "08:00", "close": "18:00" },
          "wednesday": { "open": "08:00", "close": "18:00" },
          "thursday": { "open": "08:00", "close": "18:00" },
          "friday": { "open": "08:00", "close": "18:00" },
          "saturday": { "open": "08:00", "close": "12:00" }
        },
        priceRange: "$$",
        rating: 4,
        reviewCount: 167,
        isVerified: true,
        isActive: true,
      },

      {
        cityId: lagoaSantaCity?.id || "",
        name: "Salão Beleza Natural",
        slug: "salao-beleza-natural",
        category: "services",
        subcategory: "beauty",
        phone: "(31) 3681-2222",
        whatsapp: "5531368122222",
        address: "Rua da Beleza, 159",
        neighborhood: "Centro",
        postalCode: "33400-000",
        coordinates: "-19.6370,-43.8940",
        description: "Salão de beleza completo com tratamentos estéticos e cabeleireiro.",
        services: ["Corte", "Coloração", "Manicure", "Estética"],
        workingHours: {
          "tuesday": { "open": "09:00", "close": "18:00" },
          "wednesday": { "open": "09:00", "close": "18:00" },
          "thursday": { "open": "09:00", "close": "18:00" },
          "friday": { "open": "09:00", "close": "18:00" },
          "saturday": { "open": "08:00", "close": "17:00" }
        },
        priceRange: "$$",
        rating: 5,
        reviewCount: 245,
        isVerified: true,
        isActive: true,
      },
    ];

    // Create businesses
    businessesData.forEach(businessData => {
      const business: Business = {
        id: randomUUID(),
        ...businessData,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.businesses.set(business.id, business);
    });
  }

  // Cities methods
  async getCities(): Promise<City[]> {
    return Array.from(this.cities.values()).filter(city => city.isActive);
  }

  async getCity(slug: string): Promise<City | undefined> {
    return Array.from(this.cities.values()).find(city => city.slug === slug && city.isActive);
  }

  async getCityWithBusinesses(slug: string): Promise<CityWithBusinesses | undefined> {
    const city = await this.getCity(slug);
    if (!city) return undefined;

    const businesses = await this.getBusinessesByCity(city.id);
    const businessCount = businesses.length;
    const topCategories = [...new Set(businesses.map(b => b.category))].slice(0, 5);

    return {
      ...city,
      businesses,
      businessCount,
      topCategories,
    };
  }

  async createCity(cityData: InsertCity): Promise<City> {
    const city: City = {
      id: randomUUID(),
      ...cityData,
      createdAt: new Date(),
    };
    this.cities.set(city.id, city);
    return city;
  }

  // Business methods
  async getBusinesses(): Promise<Business[]> {
    return Array.from(this.businesses.values()).filter(business => business.isActive);
  }

  async getBusinessesByCity(cityId: string): Promise<Business[]> {
    return Array.from(this.businesses.values()).filter(
      business => business.cityId === cityId && business.isActive
    );
  }

  async getBusinessesByCategory(category: string): Promise<Business[]> {
    return Array.from(this.businesses.values()).filter(
      business => business.category === category && business.isActive
    );
  }

  async getBusinessesByCityAndCategory(cityId: string, category: string): Promise<Business[]> {
    return Array.from(this.businesses.values()).filter(
      business => business.cityId === cityId && business.category === category && business.isActive
    );
  }

  async getBusiness(id: string): Promise<Business | undefined> {
    return this.businesses.get(id);
  }

  async createBusiness(businessData: InsertBusiness): Promise<Business> {
    const business: Business = {
      id: randomUUID(),
      ...businessData,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.businesses.set(business.id, business);
    return business;
  }

  async searchBusinesses(query: string, cityId?: string): Promise<Business[]> {
    const searchTerm = query.toLowerCase();
    let businesses = Array.from(this.businesses.values()).filter(business => business.isActive);

    if (cityId) {
      businesses = businesses.filter(business => business.cityId === cityId);
    }

    return businesses.filter(business => 
      business.name.toLowerCase().includes(searchTerm) ||
      business.description?.toLowerCase().includes(searchTerm) ||
      business.category.toLowerCase().includes(searchTerm) ||
      business.subcategory?.toLowerCase().includes(searchTerm) ||
      business.services?.some(service => service.toLowerCase().includes(searchTerm))
    );
  }

  // Business Categories methods
  async getBusinessCategories(): Promise<BusinessCategory[]> {
    return Array.from(this.businessCategories.values()).filter(category => category.isActive);
  }

  async getBusinessCategory(slug: string): Promise<BusinessCategory | undefined> {
    return Array.from(this.businessCategories.values()).find(
      category => category.slug === slug && category.isActive
    );
  }

  async createBusinessCategory(categoryData: InsertBusinessCategory): Promise<BusinessCategory> {
    const category: BusinessCategory = {
      id: randomUUID(),
      ...categoryData,
    };
    this.businessCategories.set(category.id, category);
    return category;
  }
}

export const businessStorage = new MemBusinessStorage();