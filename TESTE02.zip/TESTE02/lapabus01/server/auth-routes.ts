import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import { authStorage } from "./auth-storage";
import { externalBusinessService } from "./external-business-service";
import { businessStorage } from "./business-storage";
import { tourismService } from "./tourism-service";
import { loginSchema, createUserSchema } from "@shared/auth-schema";

// Extend Express Request to include session
interface AuthenticatedRequest extends Request {
  session: any & {
    userId?: string;
    username?: string;
    email?: string;
    role?: "admin" | "user";
    isAuthenticated?: boolean;
  };
}

export function createAuthRoutes() {
  const router = Router();

  // Middleware to check authentication
  const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.session.isAuthenticated) {
      return res.status(401).json({ success: false, error: "Não autenticado" });
    }
    next();
  };

  // Middleware to check admin role
  const requireAdmin = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.session.isAuthenticated || req.session.role !== "admin") {
      return res.status(403).json({ success: false, error: "Acesso negado - apenas administradores" });
    }
    next();
  };

  // Login route
  router.post("/login", async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await authStorage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ success: false, error: "Usuário ou senha inválidos" });
      }

      if (!user.isActive) {
        return res.status(401).json({ success: false, error: "Usuário desativado" });
      }

      const isValidPassword = await authStorage.verifyPassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ success: false, error: "Usuário ou senha inválidos" });
      }

      // Set session data
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.email = user.email;
      req.session.role = user.role;
      req.session.isAuthenticated = true;

      // Return user data without password
      const { password: _, ...userWithoutPassword } = user;
      res.json({ 
        success: true, 
        data: { 
          user: userWithoutPassword,
          message: "Login realizado com sucesso"
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ success: false, error: "Dados inválidos", details: error.errors });
      }
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Logout route
  router.post("/logout", (req: AuthenticatedRequest, res: Response) => {
    req.session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ success: false, error: "Erro ao fazer logout" });
      }
      res.json({ success: true, message: "Logout realizado com sucesso" });
    });
  });

  // Get current user
  router.get("/me", requireAuth, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = await authStorage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ success: false, error: "Usuário não encontrado" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json({ success: true, data: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Create user (admin only)
  router.post("/users", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userData = createUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await authStorage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ success: false, error: "Nome de usuário já existe" });
      }

      // Check if email already exists
      const existingEmail = await authStorage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(409).json({ success: false, error: "Email já está em uso" });
      }

      const user = await authStorage.createUser(userData);
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(201).json({ success: true, data: userWithoutPassword });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ success: false, error: "Dados inválidos", details: error.errors });
      }
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Get all users (admin only)
  router.get("/users", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const users = await authStorage.getAllUsers();
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json({ success: true, data: usersWithoutPasswords });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Delete user (admin only)
  router.delete("/users/:id", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      
      // Prevent admin from deleting themselves
      if (id === req.session.userId) {
        return res.status(400).json({ success: false, error: "Não é possível deletar sua própria conta" });
      }

      const deleted = await authStorage.deleteUser(id);
      if (!deleted) {
        return res.status(404).json({ success: false, error: "Usuário não encontrado" });
      }

      res.json({ success: true, message: "Usuário deletado com sucesso" });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Settings routes (admin only)
  router.get("/settings", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const settings = await authStorage.getSettings();
      res.json({ success: true, data: settings });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  router.get("/settings/category/:category", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { category } = req.params;
      const settings = await authStorage.getSettingsByCategory(category);
      res.json({ success: true, data: settings });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  router.put("/settings/:key", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { key } = req.params;
      const { value } = req.body;
      
      if (typeof value !== "string") {
        return res.status(400).json({ success: false, error: "Valor deve ser uma string" });
      }

      const setting = await authStorage.updateSetting(key, value);
      if (!setting) {
        return res.status(404).json({ success: false, error: "Configuração não encontrada" });
      }

      res.json({ success: true, data: setting });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // Public settings (no auth required)
  router.get("/public-settings", async (req, res) => {
    try {
      const allSettings = await authStorage.getSettings();
      const publicSettings = allSettings.filter(setting => setting.isPublic);
      res.json({ success: true, data: publicSettings });
    } catch (error) {
      res.status(500).json({ success: false, error: "Erro interno do servidor" });
    }
  });

  // External Business API routes (admin only)
  
  // Buscar empresas por cidade usando APIs externas
  router.post("/external/search-businesses", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, state } = req.body;
      
      if (!cityName) {
        return res.status(400).json({ success: false, error: "Nome da cidade é obrigatório" });
      }

      const businesses = await externalBusinessService.searchBusinessesByCity(cityName, state || "MG");
      
      res.json({ 
        success: true, 
        data: {
          businesses,
          total: businesses.length,
          message: `Encontradas ${businesses.length} empresas para ${cityName}`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar empresas:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar empresas via APIs externas" });
    }
  });

  // Buscar empresa por CNPJ
  router.post("/external/search-cnpj", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cnpj } = req.body;
      
      if (!cnpj) {
        return res.status(400).json({ success: false, error: "CNPJ é obrigatório" });
      }

      const business = await externalBusinessService.getBusinessByCNPJ(cnpj);
      
      if (!business) {
        return res.status(404).json({ success: false, error: "Empresa não encontrada para este CNPJ" });
      }

      res.json({ success: true, data: business });
    } catch (error) {
      console.error('Erro ao buscar CNPJ:', error);
      res.status(500).json({ success: false, error: "Erro ao consultar CNPJ" });
    }
  });

  // Geocodificar endereço
  router.post("/external/geocode", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { address, city, state } = req.body;
      
      if (!address) {
        return res.status(400).json({ success: false, error: "Endereço é obrigatório" });
      }

      const coordinates = await externalBusinessService.geocodeAddress(address, city, state);
      
      if (!coordinates) {
        return res.status(404).json({ success: false, error: "Não foi possível geocodificar o endereço" });
      }

      res.json({ success: true, data: coordinates });
    } catch (error) {
      console.error('Erro na geocodificação:', error);
      res.status(500).json({ success: false, error: "Erro na geocodificação" });
    }
  });

  // Buscar empresas próximas a uma coordenada
  router.post("/external/search-nearby", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { lat, lng, radius } = req.body;
      
      if (!lat || !lng) {
        return res.status(400).json({ success: false, error: "Latitude e longitude são obrigatórias" });
      }

      const businesses = await externalBusinessService.searchNearbyBusinesses(
        parseFloat(lat), 
        parseFloat(lng), 
        radius || 1000
      );
      
      res.json({ 
        success: true, 
        data: {
          businesses,
          total: businesses.length,
          coordinates: { lat: parseFloat(lat), lng: parseFloat(lng) }
        }
      });
    } catch (error) {
      console.error('Erro ao buscar empresas próximas:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar empresas próximas" });
    }
  });

  // Importar empresas externas para o banco de dados
  router.post("/external/import-businesses", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { businesses, cityId } = req.body;
      
      if (!businesses || !Array.isArray(businesses)) {
        return res.status(400).json({ success: false, error: "Lista de empresas é obrigatória" });
      }

      if (!cityId) {
        return res.status(400).json({ success: false, error: "ID da cidade é obrigatório" });
      }

      // Verificar se a cidade existe
      const cities = await businessStorage.getCities();
      const city = cities.find(c => c.id === cityId);
      if (!city) {
        return res.status(404).json({ success: false, error: "Cidade não encontrada" });
      }

      const imported = [];
      const errors = [];

      for (const externalBusiness of businesses) {
        try {
          // Validar dados da empresa
          if (!externalBusinessService.validateBusinessData(externalBusiness)) {
            errors.push(`Empresa ${externalBusiness.name || 'sem nome'}: dados inválidos`);
            continue;
          }

          // Verificar se já existe (por nome e endereço)
          const existingBusinesses = await businessStorage.getBusinessesByCity(cityId);
          const duplicate = existingBusinesses.find(b => 
            b.name.toLowerCase() === externalBusiness.name.toLowerCase() &&
            b.address.toLowerCase() === externalBusiness.address.toLowerCase()
          );

          if (duplicate) {
            errors.push(`Empresa ${externalBusiness.name}: já existe no sistema`);
            continue;
          }

          // Buscar CEP se não informado
          let postalCode = externalBusiness.postalCode;
          let neighborhood = externalBusiness.neighborhood;

          if (!postalCode && externalBusiness.coordinates) {
            // Tentar buscar dados do endereço por coordenadas (reverso)
            // Aqui poderia implementar busca reversa de CEP
          }

          // Converter para formato de inserção
          const businessData = externalBusinessService.convertToInsertBusiness(
            externalBusiness,
            cityId,
            neighborhood,
            postalCode
          );

          // Inserir no banco
          const created = await businessStorage.createBusiness(businessData);
          imported.push(created);

        } catch (error) {
          errors.push(`Empresa ${externalBusiness.name || 'sem nome'}: ${error.message}`);
        }
      }

      res.json({ 
        success: true, 
        data: {
          imported: imported.length,
          errors: errors.length,
          total: businesses.length,
          businesses: imported,
          errorDetails: errors
        },
        message: `Importadas ${imported.length} de ${businesses.length} empresas`
      });

    } catch (error) {
      console.error('Erro na importação:', error);
      res.status(500).json({ success: false, error: "Erro na importação de empresas" });
    }
  });

  // Buscar endereço por CEP
  router.post("/external/search-cep", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cep } = req.body;
      
      if (!cep) {
        return res.status(400).json({ success: false, error: "CEP é obrigatório" });
      }

      const addressData = await externalBusinessService.getAddressByCEP(cep);
      
      if (!addressData) {
        return res.status(404).json({ success: false, error: "CEP não encontrado" });
      }

      res.json({ success: true, data: addressData });
    } catch (error) {
      console.error('Erro ao buscar CEP:', error);
      res.status(500).json({ success: false, error: "Erro ao consultar CEP" });
    }
  });

  // Endpoint para popular automaticamente empresas de uma cidade
  router.post("/external/auto-populate", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityId, limit = 50 } = req.body;
      
      if (!cityId) {
        return res.status(400).json({ success: false, error: "ID da cidade é obrigatório" });
      }

      // Buscar dados da cidade
      const cities = await businessStorage.getCities();
      const city = cities.find(c => c.id === cityId);
      if (!city) {
        return res.status(404).json({ success: false, error: "Cidade não encontrada" });
      }

      // Buscar empresas via APIs externas
      const externalBusinesses = await externalBusinessService.searchBusinessesByCity(city.name, city.state);
      
      // Limitar quantidade
      const businessesToImport = externalBusinesses.slice(0, limit);
      
      // Importar automaticamente
      const imported = [];
      const errors = [];

      for (const externalBusiness of businessesToImport) {
        try {
          if (!externalBusinessService.validateBusinessData(externalBusiness)) {
            continue;
          }

          const businessData = externalBusinessService.convertToInsertBusiness(
            externalBusiness,
            cityId
          );

          const created = await businessStorage.createBusiness(businessData);
          imported.push(created);
          
          // Rate limiting
          await new Promise(resolve => setTimeout(resolve, 500));

        } catch (error) {
          errors.push(error.message);
        }
      }

      res.json({
        success: true,
        data: {
          city: city.name,
          found: externalBusinesses.length,
          imported: imported.length,
          errors: errors.length,
          businesses: imported
        },
        message: `Auto-população concluída: ${imported.length} empresas adicionadas em ${city.name}`
      });

    } catch (error) {
      console.error('Erro na auto-população:', error);
      res.status(500).json({ success: false, error: "Erro na auto-população de empresas" });
    }
  });

  // Tourism API routes (admin only)
  
  // Buscar atrações turísticas por cidade
  router.post("/tourism/search-attractions", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, latitude, longitude, radius, category, minRating, limit } = req.body;
      
      if (!cityName && (!latitude || !longitude)) {
        return res.status(400).json({ 
          success: false, 
          error: "Nome da cidade ou coordenadas são obrigatórios" 
        });
      }

      const options = {
        cityName,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        radius: radius ? parseInt(radius) : 5000,
        category,
        minRating: minRating ? parseFloat(minRating) : undefined,
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchAllAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          message: `Encontradas ${attractions.length} atrações turísticas`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações turísticas:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações turísticas" });
    }
  });

  // Buscar atrações usando apenas OpenStreetMap (gratuito)
  router.post("/tourism/search-osm", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, latitude, longitude, radius, limit } = req.body;
      
      const options = {
        cityName,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        radius: radius ? parseInt(radius) : 5000,
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchOSMTourismAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          source: 'OpenStreetMap (Gratuito)',
          message: `Encontradas ${attractions.length} atrações via OSM`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações OSM:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações via OpenStreetMap" });
    }
  });

  // Buscar atrações usando Amadeus
  router.post("/tourism/search-amadeus", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { latitude, longitude, radius, category, limit } = req.body;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ 
          success: false, 
          error: "Latitude e longitude são obrigatórias para busca Amadeus" 
        });
      }

      const options = {
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        radius: radius ? parseInt(radius) : 5000,
        category,
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchAmadeusAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          source: 'Amadeus Points of Interest',
          message: `Encontradas ${attractions.length} atrações via Amadeus`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações Amadeus:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações via Amadeus" });
    }
  });

  // Buscar atrações usando Geoapify
  router.post("/tourism/search-geoapify", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, latitude, longitude, radius, category, limit } = req.body;
      
      const options = {
        cityName,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        radius: radius ? parseInt(radius) : 5000,
        category,
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchGeoapifyAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          source: 'Geoapify Places API',
          message: `Encontradas ${attractions.length} atrações via Geoapify`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações Geoapify:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações via Geoapify" });
    }
  });

  // Buscar atrações usando TripAdvisor
  router.post("/tourism/search-tripadvisor", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, latitude, longitude, language, limit } = req.body;
      
      const options = {
        cityName,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        language: language || 'pt',
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchTripAdvisorAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          source: 'TripAdvisor Content API',
          message: `Encontradas ${attractions.length} atrações via TripAdvisor`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações TripAdvisor:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações via TripAdvisor" });
    }
  });

  // Buscar atrações usando LocationIQ
  router.post("/tourism/search-locationiq", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityName, latitude, longitude, limit } = req.body;
      
      const options = {
        cityName,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        limit: limit ? parseInt(limit) : 20
      };

      const attractions = await tourismService.searchLocationIQAttractions(options);
      
      res.json({ 
        success: true, 
        data: {
          attractions,
          total: attractions.length,
          source: 'LocationIQ',
          message: `Encontradas ${attractions.length} atrações via LocationIQ`
        }
      });
    } catch (error) {
      console.error('Erro ao buscar atrações LocationIQ:', error);
      res.status(500).json({ success: false, error: "Erro ao buscar atrações via LocationIQ" });
    }
  });

  // Importar atrações turísticas para o banco de dados
  router.post("/tourism/import-attractions", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { attractions, cityId } = req.body;
      
      if (!attractions || !Array.isArray(attractions)) {
        return res.status(400).json({ success: false, error: "Lista de atrações é obrigatória" });
      }

      if (!cityId) {
        return res.status(400).json({ success: false, error: "ID da cidade é obrigatório" });
      }

      // Verificar se a cidade existe
      const cities = await businessStorage.getCities();
      const city = cities.find(c => c.id === cityId);
      if (!city) {
        return res.status(404).json({ success: false, error: "Cidade não encontrada" });
      }

      const imported = [];
      const errors = [];

      for (const attraction of attractions) {
        try {
          // Validar dados da atração
          if (!tourismService.validateAttractionData(attraction)) {
            errors.push(`Atração ${attraction.name || 'sem nome'}: dados inválidos`);
            continue;
          }

          // Verificar se já existe (por nome e endereço)
          const existingBusinesses = await businessStorage.getBusinessesByCity(cityId);
          const duplicate = existingBusinesses.find(b => 
            b.name.toLowerCase() === attraction.name.toLowerCase() &&
            b.address.toLowerCase().includes(attraction.address.toLowerCase())
          );

          if (duplicate) {
            errors.push(`Atração ${attraction.name}: já existe no sistema`);
            continue;
          }

          // Converter para formato de inserção
          const attractionData = tourismService.convertToInsertAttraction(
            attraction,
            cityId
          );

          // Inserir no banco como empresa turística
          const created = await businessStorage.createBusiness(attractionData);
          imported.push(created);

        } catch (error) {
          errors.push(`Atração ${attraction.name || 'sem nome'}: ${error.message}`);
        }
      }

      res.json({ 
        success: true, 
        data: {
          imported: imported.length,
          errors: errors.length,
          total: attractions.length,
          attractions: imported,
          errorDetails: errors
        },
        message: `Importadas ${imported.length} de ${attractions.length} atrações turísticas`
      });

    } catch (error) {
      console.error('Erro na importação de atrações:', error);
      res.status(500).json({ success: false, error: "Erro na importação de atrações turísticas" });
    }
  });

  // Auto-popular atrações turísticas de uma cidade
  router.post("/tourism/auto-populate", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { cityId, limit = 30, useOnlyFree = true } = req.body;
      
      if (!cityId) {
        return res.status(400).json({ success: false, error: "ID da cidade é obrigatório" });
      }

      // Buscar dados da cidade
      const cities = await businessStorage.getCities();
      const city = cities.find(c => c.id === cityId);
      if (!city) {
        return res.status(404).json({ success: false, error: "Cidade não encontrada" });
      }

      // Buscar atrações via APIs
      let attractions = [];
      if (useOnlyFree) {
        // Usar apenas APIs gratuitas (OSM)
        attractions = await tourismService.searchOSMTourismAttractions({
          cityName: city.name,
          limit
        });
      } else {
        // Usar todas as APIs disponíveis
        attractions = await tourismService.searchAllAttractions({
          cityName: city.name,
          limit
        });
      }
      
      // Limitar quantidade
      const attractionsToImport = attractions.slice(0, limit);
      
      // Importar automaticamente
      const imported = [];
      const errors = [];

      for (const attraction of attractionsToImport) {
        try {
          if (!tourismService.validateAttractionData(attraction)) {
            continue;
          }

          const attractionData = tourismService.convertToInsertAttraction(
            attraction,
            cityId
          );

          const created = await businessStorage.createBusiness(attractionData);
          imported.push(created);
          
          // Rate limiting
          await new Promise(resolve => setTimeout(resolve, 300));

        } catch (error) {
          errors.push(error.message);
        }
      }

      res.json({
        success: true,
        data: {
          city: city.name,
          found: attractions.length,
          imported: imported.length,
          errors: errors.length,
          attractions: imported,
          apiUsed: useOnlyFree ? 'OpenStreetMap (Gratuito)' : 'Todas as APIs disponíveis'
        },
        message: `Auto-população de turismo concluída: ${imported.length} atrações adicionadas em ${city.name}`
      });

    } catch (error) {
      console.error('Erro na auto-população de turismo:', error);
      res.status(500).json({ success: false, error: "Erro na auto-população de atrações turísticas" });
    }
  });

  // Verificar status das APIs de turismo
  router.get("/tourism/api-status", requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const status = {
        osm: { available: true, cost: 'Gratuito', description: 'OpenStreetMap - dados abertos' },
        amadeus: { 
          available: !!(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET),
          cost: '400 req/grátis + pay-as-you-go',
          description: 'Amadeus Points of Interest - popularidade e scores'
        },
        geoapify: { 
          available: !!process.env.GEOAPIFY_API_KEY,
          cost: 'Plano gratuito disponível',
          description: 'Geoapify Places - 500+ categorias com filtros'
        },
        tripadvisor: { 
          available: !!process.env.TRIPADVISOR_API_KEY,
          cost: '10k buscas/dia grátis',
          description: 'TripAdvisor Content - avaliações e fotos'
        },
        locationiq: { 
          available: !!process.env.LOCATIONIQ_API_KEY,
          cost: 'Plano gratuito disponível',
          description: 'LocationIQ - geocodificação e POIs'
        },
        foursquare: { 
          available: !!process.env.FOURSQUARE_API_KEY,
          cost: 'Créditos iniciais grátis',
          description: 'Foursquare Places - taxonomia ampla'
        }
      };

      const availableCount = Object.values(status).filter(api => api.available).length;
      
      res.json({
        success: true,
        data: {
          status,
          summary: {
            total: Object.keys(status).length,
            available: availableCount,
            configured: availableCount,
            freeAvailable: status.osm.available
          }
        }
      });
    } catch (error) {
      console.error('Erro ao verificar status das APIs:', error);
      res.status(500).json({ success: false, error: "Erro ao verificar status das APIs" });
    }
  });

  return router;
}