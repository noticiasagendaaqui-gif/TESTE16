import axios from 'axios';

export interface TourismAttraction {
  id: string;
  name: string;
  description?: string;
  category: string;
  subcategory?: string;
  address: string;
  coordinates?: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  website?: string;
  email?: string;
  rating?: number;
  reviewCount?: number;
  photos?: string[];
  tags?: string[];
  openingHours?: string;
  priceRange?: string;
  accessibility?: string[];
  source: 'amadeus' | 'geoapify' | 'tripadvisor' | 'foursquare' | 'osm' | 'locationiq';
  sourceId: string;
  popularity?: number;
  verified?: boolean;
  lastUpdated: Date;
}

export interface TourismSearchOptions {
  cityName?: string;
  latitude?: number;
  longitude?: number;
  radius?: number; // in meters
  category?: string;
  minRating?: number;
  limit?: number;
  language?: string;
}

export class TourismService {
  private amadeus: {
    clientId?: string;
    clientSecret?: string;
    accessToken?: string;
    tokenExpiry?: Date;
  } = {};

  private geoapifyKey?: string;
  private tripAdvisorKey?: string;
  private locationIqKey?: string;

  constructor() {
    // Initialize API keys from environment variables
    this.amadeus.clientId = process.env.AMADEUS_CLIENT_ID;
    this.amadeus.clientSecret = process.env.AMADEUS_CLIENT_SECRET;
    this.geoapifyKey = process.env.GEOAPIFY_API_KEY;
    this.tripAdvisorKey = process.env.TRIPADVISOR_API_KEY;
    this.locationIqKey = process.env.LOCATIONIQ_API_KEY;
  }

  // Get Amadeus access token
  private async getAmadeusToken(): Promise<string | null> {
    if (!this.amadeus.clientId || !this.amadeus.clientSecret) {
      console.log('Amadeus credentials not configured');
      return null;
    }

    try {
      // Check if token is still valid
      if (this.amadeus.accessToken && this.amadeus.tokenExpiry && 
          this.amadeus.tokenExpiry > new Date()) {
        return this.amadeus.accessToken;
      }

      // Get new token
      const response = await axios.post('https://api.amadeus.com/v1/security/oauth2/token', {
        grant_type: 'client_credentials',
        client_id: this.amadeus.clientId,
        client_secret: this.amadeus.clientSecret
      }, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });

      this.amadeus.accessToken = response.data.access_token;
      this.amadeus.tokenExpiry = new Date(Date.now() + (response.data.expires_in * 1000));
      
      return this.amadeus.accessToken;
    } catch (error) {
      console.error('Error getting Amadeus token:', error);
      return null;
    }
  }

  // Search attractions using Amadeus Points of Interest API
  async searchAmadeusAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    const token = await this.getAmadeusToken();
    if (!token) return [];

    try {
      const params: any = {};
      
      if (options.latitude && options.longitude) {
        params.latitude = options.latitude;
        params.longitude = options.longitude;
      }
      
      if (options.radius) {
        params.radius = Math.min(options.radius, 50000); // Max 50km
      }
      
      if (options.category) {
        params.categories = options.category;
      }

      const response = await axios.get('https://api.amadeus.com/v1/reference-data/locations/pois', {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params
      });

      return response.data.data?.map((poi: any) => this.mapAmadeusToAttraction(poi)) || [];
    } catch (error) {
      console.error('Error searching Amadeus attractions:', error);
      return [];
    }
  }

  // Search using Geoapify Places API
  async searchGeoapifyAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    if (!this.geoapifyKey) {
      console.log('Geoapify API key not configured');
      return [];
    }

    try {
      const params: any = {
        apiKey: this.geoapifyKey,
        limit: options.limit || 20,
        format: 'json'
      };

      // Location-based search
      if (options.latitude && options.longitude) {
        params.filter = `circle:${options.longitude},${options.latitude},${options.radius || 5000}`;
      } else if (options.cityName) {
        params.filter = `place:${options.cityName}`;
      }

      // Category filters - tourism related
      const categories = [
        'tourism', 'tourism.attraction', 'tourism.museum', 
        'tourism.zoo', 'tourism.theme_park', 'heritage', 
        'natural', 'entertainment', 'leisure.park'
      ];
      
      if (options.category) {
        params.categories = options.category;
      } else {
        params.categories = categories.join(',');
      }

      const response = await axios.get('https://api.geoapify.com/v2/places', { params });

      return response.data.features?.map((feature: any) => this.mapGeoapifyToAttraction(feature)) || [];
    } catch (error) {
      console.error('Error searching Geoapify attractions:', error);
      return [];
    }
  }

  // Search using TripAdvisor Content API
  async searchTripAdvisorAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    if (!this.tripAdvisorKey) {
      console.log('TripAdvisor API key not configured');
      return [];
    }

    try {
      const params: any = {
        key: this.tripAdvisorKey,
        searchQuery: options.cityName || '',
        category: 'attractions',
        language: options.language || 'pt'
      };

      if (options.latitude && options.longitude) {
        params.latLong = `${options.latitude},${options.longitude}`;
      }

      const response = await axios.get('https://api.content.tripadvisor.com/api/v1/location/search', { params });

      return response.data.data?.map((location: any) => this.mapTripAdvisorToAttraction(location)) || [];
    } catch (error) {
      console.error('Error searching TripAdvisor attractions:', error);
      return [];
    }
  }

  // Search using LocationIQ
  async searchLocationIQAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    if (!this.locationIqKey) {
      console.log('LocationIQ API key not configured');
      return [];
    }

    try {
      const params: any = {
        key: this.locationIqKey,
        format: 'json',
        limit: options.limit || 20,
        extratags: 1,
        namedetails: 1
      };

      let query = '';
      if (options.cityName) {
        query = `tourism in ${options.cityName}`;
      } else if (options.latitude && options.longitude) {
        // Reverse geocoding with tourism filter
        params.lat = options.latitude;
        params.lon = options.longitude;
        query = 'tourism';
      }

      params.q = query;

      const response = await axios.get('https://us1.locationiq.com/v1/search.php', { params });

      return response.data?.map((place: any) => this.mapLocationIQToAttraction(place)) || [];
    } catch (error) {
      console.error('Error searching LocationIQ attractions:', error);
      return [];
    }
  }

  // Enhanced OpenStreetMap search for tourism
  async searchOSMTourismAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    try {
      const params: any = {
        format: 'json',
        limit: options.limit || 20,
        extratags: 1,
        namedetails: 1
      };

      // Build tourism-specific query
      const tourismTags = [
        'tourism=attraction',
        'tourism=museum',
        'tourism=zoo',
        'tourism=theme_park',
        'historic=*',
        'leisure=park',
        'amenity=place_of_worship'
      ];

      let query = '';
      if (options.cityName) {
        query = `[tourism] in ${options.cityName}, Minas Gerais, Brazil`;
      } else if (options.latitude && options.longitude) {
        // Use Overpass API for more specific queries
        return this.searchOverpassTourism(options);
      }

      params.q = query;

      const response = await axios.get('https://nominatim.openstreetmap.org/search', { params });

      return response.data?.map((place: any) => this.mapOSMToAttraction(place)) || [];
    } catch (error) {
      console.error('Error searching OSM tourism attractions:', error);
      return [];
    }
  }

  // Use Overpass API for detailed OSM tourism data
  private async searchOverpassTourism(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    try {
      const { latitude, longitude, radius = 5000 } = options;
      
      const overpassQuery = `
        [out:json][timeout:25];
        (
          node["tourism"](around:${radius},${latitude},${longitude});
          way["tourism"](around:${radius},${latitude},${longitude});
          relation["tourism"](around:${radius},${latitude},${longitude});
          node["historic"](around:${radius},${latitude},${longitude});
          way["historic"](around:${radius},${latitude},${longitude});
          node["leisure"="park"](around:${radius},${latitude},${longitude});
          way["leisure"="park"](around:${radius},${latitude},${longitude});
        );
        out geom;
      `;

      const response = await axios.post('https://overpass-api.de/api/interpreter', overpassQuery, {
        headers: { 'Content-Type': 'text/plain' }
      });

      return response.data.elements?.map((element: any) => this.mapOverpassToAttraction(element)) || [];
    } catch (error) {
      console.error('Error searching Overpass tourism:', error);
      return [];
    }
  }

  // Comprehensive search using all available APIs
  async searchAllAttractions(options: TourismSearchOptions): Promise<TourismAttraction[]> {
    const results: TourismAttraction[] = [];
    
    // Run searches in parallel for better performance
    const searches = await Promise.allSettled([
      this.searchOSMTourismAttractions(options),
      this.searchGeoapifyAttractions(options),
      this.searchAmadeusAttractions(options),
      this.searchTripAdvisorAttractions(options),
      this.searchLocationIQAttractions(options)
    ]);

    searches.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        results.push(...result.value);
      } else {
        const apiNames = ['OSM', 'Geoapify', 'Amadeus', 'TripAdvisor', 'LocationIQ'];
        console.warn(`${apiNames[index]} search failed:`, result.reason);
      }
    });

    // Remove duplicates and sort by relevance
    return this.deduplicateAndRank(results);
  }

  // Helper methods for mapping API responses to common format
  private mapAmadeusToAttraction(poi: any): TourismAttraction {
    return {
      id: `amadeus_${poi.id}`,
      name: poi.name || 'Atração sem nome',
      description: poi.shortDescription,
      category: this.mapAmadeusCategory(poi.category),
      subcategory: poi.subCategory,
      address: this.formatAddress(poi.address),
      coordinates: poi.geoCode ? `${poi.geoCode.latitude},${poi.geoCode.longitude}` : undefined,
      latitude: poi.geoCode?.latitude,
      longitude: poi.geoCode?.longitude,
      tags: poi.tags || [],
      source: 'amadeus',
      sourceId: poi.id,
      popularity: poi.rank,
      verified: true,
      lastUpdated: new Date()
    };
  }

  private mapGeoapifyToAttraction(feature: any): TourismAttraction {
    const props = feature.properties;
    const coords = feature.geometry?.coordinates;
    
    return {
      id: `geoapify_${props.place_id}`,
      name: props.name || 'Atração sem nome',
      description: props.description,
      category: this.mapGeoapifyCategory(props.categories?.[0]),
      address: this.formatGeoapifyAddress(props),
      coordinates: coords ? `${coords[1]},${coords[0]}` : undefined,
      latitude: coords?.[1],
      longitude: coords?.[0],
      phone: props.contact?.phone,
      website: props.contact?.website,
      openingHours: props.opening_hours,
      accessibility: props.accessibility || [],
      source: 'geoapify',
      sourceId: props.place_id,
      verified: true,
      lastUpdated: new Date()
    };
  }

  private mapTripAdvisorToAttraction(location: any): TourismAttraction {
    return {
      id: `tripadvisor_${location.location_id}`,
      name: location.name || 'Atração sem nome',
      description: location.description,
      category: 'Atração Turística',
      address: location.address_obj ? this.formatTripAdvisorAddress(location.address_obj) : '',
      coordinates: location.latitude && location.longitude ? 
        `${location.latitude},${location.longitude}` : undefined,
      latitude: parseFloat(location.latitude),
      longitude: parseFloat(location.longitude),
      rating: location.rating,
      reviewCount: location.num_reviews,
      photos: location.photo?.images?.map((img: any) => img.url) || [],
      website: location.website,
      priceRange: location.price_level,
      source: 'tripadvisor',
      sourceId: location.location_id,
      verified: true,
      lastUpdated: new Date()
    };
  }

  private mapLocationIQToAttraction(place: any): TourismAttraction {
    return {
      id: `locationiq_${place.place_id}`,
      name: place.display_name?.split(',')[0] || 'Atração sem nome',
      category: this.mapOSMCategory(place.type, place.extratags),
      address: place.display_name || '',
      coordinates: `${place.lat},${place.lon}`,
      latitude: parseFloat(place.lat),
      longitude: parseFloat(place.lon),
      tags: Object.keys(place.extratags || {}),
      source: 'locationiq',
      sourceId: place.place_id,
      verified: false,
      lastUpdated: new Date()
    };
  }

  private mapOSMToAttraction(place: any): TourismAttraction {
    return {
      id: `osm_${place.place_id}`,
      name: place.display_name?.split(',')[0] || 'Atração sem nome',
      category: this.mapOSMCategory(place.type, place.extratags),
      address: place.display_name || '',
      coordinates: `${place.lat},${place.lon}`,
      latitude: parseFloat(place.lat),
      longitude: parseFloat(place.lon),
      source: 'osm',
      sourceId: place.place_id,
      verified: false,
      lastUpdated: new Date()
    };
  }

  private mapOverpassToAttraction(element: any): TourismAttraction {
    const tags = element.tags || {};
    let coords = '';
    let lat: number | undefined;
    let lon: number | undefined;

    if (element.lat && element.lon) {
      lat = element.lat;
      lon = element.lon;
      coords = `${lat},${lon}`;
    } else if (element.center) {
      lat = element.center.lat;
      lon = element.center.lon;
      coords = `${lat},${lon}`;
    }

    return {
      id: `overpass_${element.id}`,
      name: tags.name || tags['name:pt'] || 'Atração sem nome',
      description: tags.description,
      category: this.mapOSMCategory(tags.tourism || tags.historic || tags.leisure, tags),
      address: this.formatOSMAddress(tags),
      coordinates: coords,
      latitude: lat,
      longitude: lon,
      phone: tags.phone,
      website: tags.website,
      email: tags.email,
      openingHours: tags.opening_hours,
      accessibility: this.extractAccessibility(tags),
      source: 'osm',
      sourceId: element.id.toString(),
      verified: false,
      lastUpdated: new Date()
    };
  }

  // Category mapping helpers
  private mapAmadeusCategory(category: string): string {
    const categoryMap: { [key: string]: string } = {
      'SIGHTS': 'Pontos Turísticos',
      'NIGHTLIFE': 'Vida Noturna',
      'RESTAURANT': 'Restaurantes',
      'SHOPPING': 'Compras'
    };
    return categoryMap[category] || 'Atração Turística';
  }

  private mapGeoapifyCategory(category: string): string {
    if (!category) return 'Atração Turística';
    
    const categoryMap: { [key: string]: string } = {
      'tourism': 'Turismo',
      'tourism.attraction': 'Atração Turística',
      'tourism.museum': 'Museu',
      'tourism.zoo': 'Zoológico',
      'heritage': 'Patrimônio Histórico',
      'natural': 'Atração Natural',
      'entertainment': 'Entretenimento',
      'leisure.park': 'Parque'
    };
    
    return categoryMap[category] || 'Atração Turística';
  }

  private mapOSMCategory(type: string, tags: any): string {
    if (!type) return 'Atração Turística';
    
    if (tags?.tourism) {
      const tourismMap: { [key: string]: string } = {
        'attraction': 'Atração Turística',
        'museum': 'Museu',
        'zoo': 'Zoológico',
        'theme_park': 'Parque Temático',
        'viewpoint': 'Mirante',
        'artwork': 'Arte Pública'
      };
      return tourismMap[tags.tourism] || 'Turismo';
    }
    
    if (tags?.historic) {
      return 'Patrimônio Histórico';
    }
    
    if (tags?.leisure) {
      return 'Lazer';
    }
    
    return 'Atração Turística';
  }

  // Address formatting helpers
  private formatAddress(addressObj: any): string {
    if (!addressObj) return '';
    return [
      addressObj.street,
      addressObj.city,
      addressObj.state,
      addressObj.country
    ].filter(Boolean).join(', ');
  }

  private formatGeoapifyAddress(props: any): string {
    return [
      props.street,
      props.housenumber,
      props.city,
      props.state,
      props.country
    ].filter(Boolean).join(', ');
  }

  private formatTripAdvisorAddress(addressObj: any): string {
    return [
      addressObj.street1,
      addressObj.city,
      addressObj.state,
      addressObj.country
    ].filter(Boolean).join(', ');
  }

  private formatOSMAddress(tags: any): string {
    return [
      tags['addr:street'],
      tags['addr:housenumber'],
      tags['addr:city'],
      tags['addr:state']
    ].filter(Boolean).join(', ') || '';
  }

  private extractAccessibility(tags: any): string[] {
    const accessibility: string[] = [];
    
    if (tags.wheelchair === 'yes') {
      accessibility.push('Acessível para cadeirantes');
    }
    
    if (tags['wheelchair:description']) {
      accessibility.push(tags['wheelchair:description']);
    }
    
    return accessibility;
  }

  // Deduplication and ranking
  private deduplicateAndRank(attractions: TourismAttraction[]): TourismAttraction[] {
    const uniqueAttractions = new Map<string, TourismAttraction>();
    
    attractions.forEach(attraction => {
      const key = this.generateDedupeKey(attraction);
      const existing = uniqueAttractions.get(key);
      
      if (!existing || this.isHigherQuality(attraction, existing)) {
        uniqueAttractions.set(key, attraction);
      }
    });
    
    return Array.from(uniqueAttractions.values())
      .sort((a, b) => {
        // Sort by rating, then by review count, then by verification status
        if (a.rating && b.rating) {
          return b.rating - a.rating;
        }
        if (a.reviewCount && b.reviewCount) {
          return b.reviewCount - a.reviewCount;
        }
        if (a.verified !== b.verified) {
          return a.verified ? -1 : 1;
        }
        return 0;
      });
  }

  private generateDedupeKey(attraction: TourismAttraction): string {
    const name = attraction.name.toLowerCase().trim();
    const coords = attraction.coordinates || '';
    return `${name}_${coords}`;
  }

  private isHigherQuality(attraction1: TourismAttraction, attraction2: TourismAttraction): boolean {
    // Prefer verified sources
    if (attraction1.verified !== attraction2.verified) {
      return attraction1.verified;
    }
    
    // Prefer sources with more complete data
    const score1 = this.calculateCompletenessScore(attraction1);
    const score2 = this.calculateCompletenessScore(attraction2);
    
    return score1 > score2;
  }

  private calculateCompletenessScore(attraction: TourismAttraction): number {
    let score = 0;
    
    if (attraction.description) score += 2;
    if (attraction.phone) score += 1;
    if (attraction.website) score += 1;
    if (attraction.rating) score += 2;
    if (attraction.photos && attraction.photos.length > 0) score += 2;
    if (attraction.openingHours) score += 1;
    if (attraction.coordinates) score += 1;
    
    return score;
  }

  // Validation helper
  validateAttractionData(attraction: any): boolean {
    return !!(
      attraction.name &&
      attraction.name.trim().length > 0 &&
      (attraction.address || attraction.coordinates)
    );
  }

  // Convert to insert format for database
  convertToInsertAttraction(
    attraction: TourismAttraction, 
    cityId: string,
    categoryId?: string
  ): any {
    return {
      name: attraction.name,
      description: attraction.description || '',
      category: attraction.category,
      subcategory: attraction.subcategory,
      address: attraction.address,
      phone: attraction.phone,
      website: attraction.website,
      email: attraction.email,
      latitude: attraction.latitude,
      longitude: attraction.longitude,
      rating: attraction.rating || 0,
      reviewCount: attraction.reviewCount || 0,
      photos: attraction.photos || [],
      tags: attraction.tags || [],
      openingHours: attraction.openingHours,
      priceRange: attraction.priceRange,
      accessibility: attraction.accessibility || [],
      cityId,
      categoryId: categoryId || this.getDefaultCategoryId(),
      verified: attraction.verified || false,
      source: attraction.source,
      sourceId: attraction.sourceId,
      isTourismAttraction: true
    };
  }

  private getDefaultCategoryId(): string {
    // Return a default category ID for tourism attractions
    // This should be coordinated with the existing category system
    return 'tourism-default';
  }
}

export const tourismService = new TourismService();